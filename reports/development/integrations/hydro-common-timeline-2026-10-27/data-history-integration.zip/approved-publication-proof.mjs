import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {libraryConfig,libraryCheckout,decodeArchiveEntry} from '../../../tools/library-data.mjs';
const root=process.cwd(),checkout=libraryCheckout(root),revision=libraryConfig(root).revision;
const git=args=>execFileSync('git',args,{cwd:checkout,maxBuffer:24*1024*1024,env:{...process.env,GIT_NO_LAZY_FETCH:'1'}}).toString().trim();
const base='68380579a7c7a1bd8ec97683b7517502c1389c3c',task='bd7e4eba99cbf71bf4713761a955b396a98ce6a5';
if(revision===base)throw Error('Runtime publication did not advance the paired pin');
const index=JSON.parse(git(['show',revision+':archive/index.json'])),pinned=JSON.parse(git(['show',base+':archive/index.json'])),candidate=JSON.parse(git(['show',task+':archive/index.json']));
const scopes=['assets/data/territorial-entities/','assets/data/physical-land/','assets/data/builtin-world/'];
let unchangedUnselectedMetadata=0;
for(const [file,spec] of Object.entries(pinned.files))if(!file.startsWith('reports/')&&!scopes.some(prefix=>file.startsWith(prefix))){if(JSON.stringify(index.files[file])!==JSON.stringify(spec))throw Error('Unselected pinned metadata changed: '+file);unchangedUnselectedMetadata++;}
const targets=['assets/data/physical-land/v1/manifest.json','assets/data/physical-land/v1/geometry.json.gz','assets/data/physical-land/v1/caspian-1922-land.json.gz','assets/data/physical-land/v1/caspian-1922-water.json.gz','assets/data/physical-land/v1/caspian-modern-water.json.gz','assets/data/territorial-entities/source/countries/waterbody-caspian.json','assets/data/territorial-entities/generated/v2/waterbody-caspian.json.gz','assets/data/territorial-entities/generated/v2/index.json','assets/data/builtin-world/generated/v1/index.json','assets/data/builtin-world/generated/v1/transport/countries-sha256-79581c63cbebe35531701eda99dc29b3b9e20fff8e627bbc38b7f55c25ba733a.bin'];
const receipts=[];
for(const file of targets){const spec=index.files[file],expected=candidate.files[file];if(!spec||spec.sha256!==expected?.sha256)throw Error('Candidate output changed: '+file);const bytes=decodeArchiveEntry(checkout,spec,revision);const sha256=createHash('sha256').update(bytes).digest('hex');if(sha256!==spec.sha256)throw Error('Archive bytes changed: '+file);receipts.push({file,sha256,bytes:bytes.length});}
for(const parent of [base,task,'ea843c09e790245cbcfe35a44051b2d67534ee4e'])git(['merge-base','--is-ancestor',parent,revision]);
const library=JSON.parse(git(['show',revision+':library.json']));if(!library.entities['waterbody:caspian'])throw Error('Native water source missing');
const manifest=JSON.parse(fs.readFileSync('shared/frontend/static/wasm/pandoeditor-core.manifest.json'));
const wasmAssets=Object.values(manifest.assets).map(spec=>{const bytes=fs.readFileSync('shared/frontend/static/wasm/'+spec.file),sha256=createHash('sha256').update(bytes).digest('hex');if(sha256!==spec.sha256)throw Error('Packaged WASM changed');return{file:spec.file,sha256};});
const remote=git(['ls-remote','origin','refs/heads/work/objects']).split(/\s+/)[0];if(remote!==revision)throw Error('Remote data revision differs from pin');
const result={revision,remote,branch:index.branch,parentsPreserved:true,unchangedUnselectedMetadata,inspectionScope:'Archive dependency metadata and ten directly affected outputs only; no country geometry audit or test rerun.',receipts,wasmAssets};
fs.writeFileSync('.superpowers/sdd/hydro-common-timeline/approved-publication-proof.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({revision,remote,unchangedUnselectedMetadata,affectedOutputs:receipts.length}));
