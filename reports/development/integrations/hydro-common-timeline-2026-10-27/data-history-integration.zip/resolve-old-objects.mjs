import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
const data=fs.realpathSync('.library-data/repository');
const git=(args,input)=>execFileSync('git',args,{cwd:data,input,maxBuffer:24*1024*1024,env:{...process.env,GIT_NO_LAZY_FETCH:'1'}});
const inventory=JSON.parse(fs.readFileSync('.superpowers/sdd/hydro-common-timeline/old-branch-conflicts.json'));
const ids=[...new Set(inventory.rows.map(row=>row.oid))];
const receipts=git(['cat-file','--batch-check'],ids.join('\n')+'\n').toString().trim().split('\n');
if(receipts.length!==ids.length||receipts.some(row=>!/^[a-f0-9]+ blob \d+$/.test(row)))throw Error('A conflicting historical blob is not locally available');
const paths=[...new Set(inventory.rows.map(row=>row.path))];
const allowed=file=>file==='library.json'||file==='archive/index.json'||file.startsWith('archive/blobs/')||file.startsWith('assets/data/')||file.startsWith('reports/');
for(const file of paths){if(!allowed(file)||!inventory.rows.some(row=>row.path===file&&row.stage===2))throw Error('Unexpected conflict requires separate review: '+file);}
for(let offset=0;offset<paths.length;offset+=18)git(['restore','--source=HEAD','--staged','--worktree','--',...paths.slice(offset,offset+18)]);
const remaining=git(['diff','--name-only','--diff-filter=U']).toString().trim();if(remaining)throw Error('Unresolved merge paths remain');
fs.writeFileSync('.superpowers/sdd/hydro-common-timeline/old-branch-resolution.json',JSON.stringify({paths:paths.length,locallyAvailableHistoricalBlobs:ids.length,classes:inventory.counts,
 resolution:'Current paired snapshot is active. Incoming historical contents retained by the complete old work/objects parent history; no incoming runtime or report format is reactivated.',parents:[git(['rev-parse','HEAD']).toString().trim(),git(['rev-parse','MERGE_HEAD']).toString().trim()]},null,2)+'\n');
console.log(JSON.stringify({resolved:paths.length,locallyAvailableHistoricalBlobs:ids.length}));
