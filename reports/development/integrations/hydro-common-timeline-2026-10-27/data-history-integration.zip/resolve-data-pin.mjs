import fs from 'node:fs';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
const data=fs.realpathSync('.library-data/repository');
const git=args=>execFileSync('git',args,{cwd:data,maxBuffer:24*1024*1024,env:{...process.env,GIT_NO_LAZY_FETCH:'1'}});
const pinned='68380579a7c7a1bd8ec97683b7517502c1389c3c',task='bd7e4eba99cbf71bf4713761a955b396a98ce6a5';
const scopes=['assets/data/territorial-entities/','assets/data/physical-land/','assets/data/builtin-world/'];
const owned=file=>scopes.some(prefix=>file.startsWith(prefix));
const from=revision=>JSON.parse(git(['show',revision+':archive/index.json']));
const base=from(pinned),candidate=from(task);
const merged={...base,branch:'work/objects',sourceRevision:'e5cb51a6e158f7ef0aed4a3dedaf03f691c81c63',files:{...base.files}};
for(const [file,spec] of Object.entries(candidate.files))if(owned(file))merged.files[file]=spec;
const conflicts=git(['diff','--name-only','--diff-filter=U']).toString().trim().split('\n').filter(Boolean);
for(const file of conflicts){
 if(file==='archive/index.json')continue;
 if(file!=='library.json'&&!owned(file))throw Error('Unexpected conflict requires individual review: '+file);
 git(['restore','--source='+task,'--staged','--worktree','--',file]);
}
// The auto-merged index is also a scoped generated output, not a source merge.
// The territorial index is content-addressed in the task archive; its logical path is selected by archive/index.json.
fs.writeFileSync(path.join(data,'archive/index.json'),JSON.stringify(merged)+'\n');git(['add','--','archive/index.json']);
fs.writeFileSync('.superpowers/sdd/hydro-common-timeline/merge-pinned-resolution.json',JSON.stringify({pinned,task,conflicts,rule:'Pinned unselected inputs; approved task outputs for three explicit runtime scopes and native library manifest. Both histories retained as merge parents.',branch:merged.branch},null,2)+'\n');
console.log(JSON.stringify({resolved:conflicts.length,remaining:git(['diff','--name-only','--diff-filter=U']).toString().trim()}));

