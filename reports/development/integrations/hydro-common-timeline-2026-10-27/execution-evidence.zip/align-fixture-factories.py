from pathlib import Path
import re
for p in Path('tests/unit').glob('timeline-*.test.mjs'):
 s=p.read_text();s=re.sub(r'createTerritorialFeature\(\{ objectRef:\{domain:"territorial",id:([^}]+)\}',r'createTerritorialFeature({ id:\1',s)
 p.write_text(s)
p=Path('tests/fixtures/generate-timeline-exchange.mjs');s=p.read_text().replace('schemaVersion: 1, lifetimes','schemaVersion: 3, propertyBindings: [], lifetimes').replace('id, entityId, validFrom','id, objectRef:{domain:\'territorial\',id:entityId}, validFrom').replace('row.entityId','row.objectRef.id');p.write_text(s)
p=Path('tests/fixtures/timeline-exchange/README.md');s=p.read_text(encoding='utf-8').replace('Web/App v10','Web/App v14').replace('schemaVersion **10**','schemaVersion **14**').replace('schemaVersion **1**','schemaVersion **3**').replace('Opening this file in the current web editor must fail with\nTIMELINE_ACTIVATION before changing the active project.','The current editor opens the common timeline and resolves the selected month.').replace('The calendar fixture also rejects UI activation.','The calendar fixture uses the same month-end resolver.');p.write_text(s,encoding='utf-8')
