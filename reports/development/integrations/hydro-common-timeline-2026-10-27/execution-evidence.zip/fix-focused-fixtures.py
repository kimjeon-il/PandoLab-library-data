from pathlib import Path
p=Path('apps/editor/tests/stage.test.mjs');s=p.read_text(encoding='utf-8').replace("test('will not clear an output directory it does not own', async t => {\n  const { root, put }", "test('will not clear an output directory it does not own', async t => {\n  const { root }");p.write_text(s,encoding='utf-8')
p=Path('tests/unit/product-assets.test.mjs');s=p.read_text().replace('writeFileSync, readdirSync, rmSync','writeFileSync, rmSync');p.write_text(s)
p=Path('tests/unit/timeline-live-view.test.mjs');s=p.read_text();s=s.replace('const state = createEmptyTerritorialState();\n  await initializeTestTerritorialState(state,null,{project:project});',"project.projectSetup.initialMonth='1916-01';\n  const state = createEmptyTerritorialState();\n  await initializeTestTerritorialState(state,null,{project:project});");s=s.replace("[[[10,10],[11,10],[11,11],[10,11],[10,10]]]","[[[0.1,0.1],[0.3,0.1],[0.3,0.3],[0.1,0.3],[0.1,0.1]]]")
# history test explicitly tests initial metadata, not inferred dates from shape coverage
s=s.replace("assert.equal(state.timelineCursor, '1916-01');","assert.equal(state.timelineCursor, project.projectSetup.initialMonth);")
p.write_text(s)
p=Path('tests/unit/timeline-persistence-integration.test.mjs');s=p.read_text().replace("import { projectForStorage, staticSerializerSnapshot }", "import { projectForStorage, staticSerializerSnapshot }")
s=s.replace("import test from 'node:test';","import test from 'node:test';\nimport {createNodeCoreProject} from '../helpers/core-project.mjs';")
a=s.index("test('preview geometry comes");b=s.index("\n\ntest(",a)
s=s[:a]+'''test('preview geometry comes from canonical bindings at the initial resolved month', async t => {
  const snapshot = staticSerializerSnapshot({ territorialEntities: [baseFeature()], fullAutosave: true });
  const project = serializer(snapshot).buildProject();
  const owner=await createNodeCoreProject(project);t.after(()=>owner.dispose());
  assert.deepEqual(projectPreviewGeometryRows({project,territorialFeatures:owner.documentModel.territorialViews()}).countries, [['A',shape]]);
});''' +s[b:]
p.write_text(s)
