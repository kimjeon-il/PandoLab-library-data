from pathlib import Path
p=Path('shared/frontend/js/modules/project-state.js');s=p.read_text(encoding='utf-8').replace('result.map(entity => ({ id: entity.id, entityKind: entity.properties.entityKind }))','timelineObjectCatalog({...project,territorialEntities:result})').replace('allEntities.map(feature => ({ id: feature.id, entityKind: feature.properties.entityKind }))','timelineObjectCatalog({...project,territorialEntities:allEntities})');p.write_text(s,encoding='utf-8')
p=Path('apps/editor/frontend/js/modules/project-serializer.js');s=p.read_text(encoding='utf-8');s="import {timelineObjectCatalog} from '../../../../../shared/frontend/js/modules/timeline-records.js';\n"+s;s=s.replace('identities.map(feature => ({ id: feature.id, entityKind: feature.properties.entityKind }))','timelineObjectCatalog({...fields,territorialEntities:identities})');p.write_text(s,encoding='utf-8')
p=Path('shared/core/include/pandoeditor/historicallibrary.h');s=p.read_text().replace('std::vector<std::string> missingSourceIds;','std::vector<std::string> missingSourceIds;\n    std::string rendering="{}";',1).replace('    std::string catalogKind;\n};\nstruct LibrarySearchOptions','    std::string catalogKind;\n    std::string rendering="{}";\n};\nstruct LibrarySearchOptions')
# Selection struct follows no LibrarySearchOptions marker on some current headers.
start=s.index('struct HistoricalSelection');end=s.index('};',start)
if 'rendering=' not in s[start:end]:s=s[:end]+ '    std::string rendering="{}";\n'+s[end:]
p.write_text(s)
p=Path('shared/core/src/historicallibrary.cpp');s=p.read_text().replace('version->partial,version->missingSourceIds,entity->catalogKind};','version->partial,version->missingSourceIds,entity->catalogKind,version->rendering};');p.write_text(s)
p=Path('shared/core/src/historicalinstantiation.cpp');s=p.read_text().replace('owner,period,geometry});','owner,period,geometry,value.rendering});');p.write_text(s)
# Native test checks version-bound rendering also makes it through same admission/history.
p=Path('shared/tests/hydro-timeline-tests.cpp');s=p.read_text().replace('addition.selection.type.reset();','addition.selection.rendering=R"({"stroke_widths":[[1,2]],"connectivity":{"node":"selected"}})";\n addition.selection.type.reset();');s=s.replace('assert(project.document().units.empty());','assert(project.document().timelineRecords.geometryBindings.back().rendering==addition.selection.rendering);\n assert(project.document().units.empty());');p.write_text(s)
# Common contract recursively validates numeric width profiles (canonical per-line-part shape).
p=Path('shared/core/src/timeline-records.cpp');s=p.read_text().replace('if(key=="stroke_widths"&&value.kind!=codecjson::Value::Array)fail("TIMELINE_GEOMETRY","Invalid width profile.");','''if(key=="stroke_widths") {
                if(value.kind!=codecjson::Value::Array)fail("TIMELINE_GEOMETRY","Invalid width profile.");
                for(const auto& part:value.array){
                    if(part.kind!=codecjson::Value::Array)fail("TIMELINE_GEOMETRY","Expected per-part river widths.");
                    for(const auto& width:part.array)if(width.kind!=codecjson::Value::Number||!std::isfinite(std::stod(width.raw))||std::stod(width.raw)<0)fail("TIMELINE_GEOMETRY","Invalid vertex width.");
                }
            }''');p.write_text(s)
# World effective rendering is immutable just like other record values.
p=Path('shared/frontend/js/modules/timeline-records.js');s=p.read_text().replace('if (row.value) Object.freeze(row.value);','if (row.value) Object.freeze(row.value);\n      if(row.rendering){for(const part of row.rendering.stroke_widths || [])Object.freeze(part);if(row.rendering.stroke_widths)Object.freeze(row.rendering.stroke_widths);Object.freeze(row.rendering);}');p.write_text(s)
print('native rendering and remaining serializer callers aligned')
