from pathlib import Path
root=Path('.')
def edit(p,a,b):
 s=Path(p).read_text(encoding='utf-8'); assert a in s,(p,a[:70]);Path(p).write_text(s.replace(a,b),encoding='utf-8')
edit('shared/core/src/timeline-resolver.cpp','geometry->geometryRef,parent?','geometry->geometryRef,geometry->rendering,parent?')
edit('shared/core/include/pandoeditor/timeline-edit.h','std::optional<GeometryRef> geometryRef;','std::optional<GeometryRef> geometryRef;\n    std::optional<std::string> rendering;')
edit('shared/core/include/pandoeditor/timeline-edit.h','const std::string& month,GeometryRef next);','const std::string& month,GeometryRef next,std::optional<std::string> rendering={});')
edit('shared/core/src/timeline-edit.cpp','const std::string& month,GeometryRef next) {','const std::string& month,GeometryRef next,std::optional<std::string> rendering) {')
edit('shared/core/src/timeline-edit.cpp','if(row.geometryRef==next)return false;row.geometryRef=next;return true;','const auto metadata=rendering.value_or(row.rendering);\n        if(row.geometryRef==next&&row.rendering==metadata)return false;row.geometryRef=next;row.rendering=metadata;return true;')
edit('shared/core/src/timeline-edit.cpp','if(!patch.geometryRef||row.geometryRef==*patch.geometryRef)return false;\n            row.geometryRef=*patch.geometryRef;return true;','const auto ref=patch.geometryRef.value_or(row.geometryRef);const auto metadata=patch.rendering.value_or(row.rendering);\n            if(row.geometryRef==ref&&row.rendering==metadata)return false;row.geometryRef=ref;row.rendering=metadata;return true;')
edit('shared/core/src/timeline-edit.cpp','if(patch.geometryRef)throw','if(patch.geometryRef||patch.rendering)throw')
edit('shared/core/src/timeline-edit.cpp','parts.push_back(std::to_string(r.geometryRef.version));','parts.push_back(std::to_string(r.geometryRef.version));parts.push_back(r.rendering);')
# record JSON optional only when actual per-shape rendering exists
edit('shared/core/src/projectcodec.cpp','{"id","objectRef","validFrom","validTo","geometryRef"});result.geometryBindings.push_back','{"id","objectRef","validFrom","validTo","geometryRef","rendering"});result.geometryBindings.push_back')
edit('shared/core/src/projectcodec.cpp','geometryRef(field(row,"geometryRef"),d,"/timelineRecords/geometryBindings/geometryRef")});','geometryRef(field(row,"geometryRef"),d,"/timelineRecords/geometryBindings/geometryRef"),row.object.count("rendering")?field(row,"rendering").encode():"{}"});')
edit('shared/core/src/projectcodec.cpp','value.object["geometryRef"]=geometryRefValue(record.geometryRef);bindings','value.object["geometryRef"]=geometryRefValue(record.geometryRef);if(record.rendering!="{}")value.object["rendering"]=codecjson::parse(record.rendering);bindings')
edit('shared/wasm/timeline-bindings.cpp','{"id","objectRef","validFrom","validTo","geometryRef"},','{"id","objectRef","validFrom","validTo","geometryRef","rendering"},')
edit('shared/wasm/timeline-bindings.cpp','readValidity(row),readRef(row["geometryRef"])});','readValidity(row),readRef(row["geometryRef"]),row["rendering"].isUndefined()?"{}":val::global("JSON").call<val>("stringify",row["rendering"]).as<std::string>()});')
edit('shared/wasm/timeline-bindings.cpp','value.set("geometryRef",webRef(row.geometryRef));bindings','value.set("geometryRef",webRef(row.geometryRef));if(row.rendering!="{}")value.set("rendering",val::global("JSON").call<val>("parse",row.rendering));bindings')
edit('shared/wasm/timeline-bindings.cpp','value.set("objectRef",webObjectRef(row.objectRef));value.set("geometryRef",webRef(row.geometryRef));','value.set("objectRef",webObjectRef(row.objectRef));value.set("geometryRef",webRef(row.geometryRef));\n        value.set("rendering",val::global("JSON").call<val>("parse",row.rendering));')
edit('shared/wasm/session-bindings.cpp','v.set("geometryRef",geometry(row.geometryRef));','v.set("geometryRef",geometry(row.geometryRef));v.set("rendering",val::global("JSON").call<val>("parse",row.rendering));')
edit('shared/core/src/timeline-records.cpp','// Repository exceptions propagate unchanged;', '''const auto rendering=codecjson::parse(row.rendering);
        if(rendering.kind!=codecjson::Value::Object)fail("TIMELINE_GEOMETRY","Rendering inputs must be an object.");
        if(row.objectRef.domain=="territorial"&&!rendering.object.empty())fail("TIMELINE_KIND","Water rendering inputs on a territorial binding.");
        for(const auto& [key,value]:rendering.object) {
            if(key!="stroke_width"&&key!="stroke_widths"&&key!="border_aligned"&&key!="connectivity")fail("TIMELINE_GEOMETRY","Unknown rendering input.");
            if(key=="stroke_width"&&(value.kind!=codecjson::Value::Number||!std::isfinite(std::stod(value.raw))||std::stod(value.raw)<0))fail("TIMELINE_GEOMETRY","Invalid river width.");
            if(key=="stroke_widths"&&value.kind!=codecjson::Value::Array)fail("TIMELINE_GEOMETRY","Invalid width profile.");
            if(key=="border_aligned"&&value.kind!=codecjson::Value::Bool)fail("TIMELINE_GEOMETRY","Invalid river alignment.");
        }
        row.rendering=rendering.encode();
        // Repository exceptions propagate unchanged;''')
edit('shared/core/include/pandoeditor/commands.h','std::optional<GeometryRef> geometryBinding;','std::optional<GeometryRef> geometryBinding;\n    std::optional<std::string> geometryRendering;')
# Decode rendering at same command boundary, remove duplicate unversioned owner.
edit('shared/core/src/projectcodec.cpp','    return edit;\n}\n\nnamespace {\nProjectDocument readWebDocumentValue', '''    if(target.domain=="hydro"&&!std::holds_alternative<std::monostate>(edit.value)) {
        auto& water=std::get<HydroFeature>(edit.value);auto properties=codecjson::parse(water.annotations);auto rendering=V::obj();
        for(const auto* key:{"stroke_width","stroke_widths","border_aligned","connectivity"}) {
            const auto found=properties.object.find(key);if(found!=properties.object.end()){rendering.object[key]=found->second;properties.object.erase(found);}
        }
        if(rendering.object.empty()&&!edit.create) {
            const auto world=resolveWorld(document.timelineRecords,{timelineEntityCatalog(document),[&](const ObjectRef&,const GeometryRef& ref){return document.geometries.get(ref)!=nullptr;}},month);
            const auto* active=world.find(target);if(active)rendering=codecjson::parse(active->rendering);
        }
        if(edit.geometry&&current&&!(edit.geometryBinding==current)) {
            // Vertex profiles/connectivity describe the old shape, not its replacement.
            rendering.object.erase("stroke_widths");rendering.object.erase("connectivity");
        }
        edit.geometryRendering=rendering.encode();water.annotations=properties.encode();
    }
    return edit;
}

namespace {
ProjectDocument readWebDocumentValue''')
edit('shared/core/src/commands.cpp','else staticGeometryBinding(d,edit.target).geometryRef=*edit.geometryBinding;','else staticGeometryBinding(d,edit.target).geometryRef=*edit.geometryBinding;\n                staticGeometryBinding(d,edit.target).rendering=edit.geometryRendering.value_or("{}");')
edit('shared/core/src/commands.cpp','staticGeometryBinding(prepared.preview->change().after(),target).geometryRef});','staticGeometryBinding(prepared.preview->change().after(),target).geometryRef,staticGeometryBinding(prepared.preview->change().after(),target).rendering});')
edit('shared/core/src/commands.cpp','project.timelineMonth(),geometry);','project.timelineMonth(),geometry,staticGeometryBinding(prepared.preview->change().after(),target).rendering);')
# All equality owners must include binding data.
p=Path('shared/core/src/commands.cpp');s=p.read_text();s=s.replace('x.geometryRef==y.geometryRef;','x.geometryRef==y.geometryRef&&x.rendering==y.rendering;');p.write_text(s)
edit('shared/core/src/timeline-view.cpp','addStaticObjectRecords(result.document,ref,active?active->geometryRef:binding->geometryRef);','addStaticObjectRecords(result.document,ref,active?active->geometryRef:binding->geometryRef);\n        staticGeometryBinding(result.document,ref).rendering=active?active->rendering:binding->rendering;')
# version-specific properties returned by projected web feature for native commands/copies
edit('shared/core/src/projectcodec.cpp','else return webFeature(d,value,props,supplied);','else return webFeature(d,value,props,supplied);') # no-op marker
# Canonical stored identity must not carry per-shape fields.
edit('shared/core/src/content.cpp','"sourceFeatureId","visible"})','"sourceFeatureId","visible","stroke_width","stroke_widths","border_aligned","connectivity"})')
print('C++ rendering contract wired')
