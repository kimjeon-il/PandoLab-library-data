from pathlib import Path
import re
for name in ['timeline-edit.test.mjs','timeline-resolver.test.mjs']:
 p=Path('tests/unit')/name;s=p.read_text().replace('schemaVersion: 2,','schemaVersion: 3,');s=s.replace("({ id, entityKind: 'general' })","({ objectRef:{domain:'territorial',id}, entityKind: 'general' })")
 if name=='timeline-resolver.test.mjs':
  s=s.replace("assert.throws(() => resolve('1914-07-31'), /month/i);","assert.deepEqual(resolve('1914-07-31').entities.map(row=>row.id),resolve('1914-07').entities.map(row=>row.id));")
  s=s.replace('id: `life:${index}`, entityId,','id: `life:${index}`, objectRef:{domain:\'territorial\',id:entityId},').replace('const common = { entityId,','const common = { objectRef:{domain:\'territorial\',id:entityId},')
  s=s.replace('world.entities.map(row => row.id)','world.entities.map(row => row.objectRef.id)').replace('entities.map(row => row.id)','entities.map(row => row.objectRef.id)');s=s.replace('ids.indexOf(row.id)','ids.indexOf(row.objectRef.id)').replace('`${row.id}:${year}`','`${row.objectRef.id}:${year}`')
 p.write_text(s)
# Actual graph test derives virtual current frontend paths, not retired root source tree.
p=Path('tests/unit/product-assets.test.mjs');s=p.read_text();a=s.index("  const availablePaths = readdirSync",s.index("test('actual viewer graph"));b=s.index("  for (const name",a)
s=s[:a]+"  const {buildFrontendSnapshot}=await import('../../scripts/lib/frontend-build.mjs');\n  const snapshot=await buildFrontendSnapshot({root});\n  const paths=new Set(snapshot.viewerPaths);\n"+s[b:];p.write_text(s)
