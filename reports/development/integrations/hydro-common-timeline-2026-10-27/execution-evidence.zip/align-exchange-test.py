from pathlib import Path
p=Path('tests/unit/timeline-geopackage.test.mjs');s=p.read_text().replace('productionGeoPackage as request, spatialLayerCount','productionGeoPackage as request, spatialLayerCount,coreFileProjection');idx=s.index('const serialize =')
s=s[:idx]+"const writeProject=async project=>{const receipt=await coreFileProjection(project);return request('write',new ArrayBuffer(0),receipt.project,receipt.spatialState);};\n"+s[idx:];s=s.replace("request('write', new ArrayBuffer(0), project)","writeProject(project)").replace('v10 project','v14 project');p.write_text(s)
