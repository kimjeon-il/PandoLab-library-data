from pathlib import Path
p=Path('tools/library-data.mjs');s=p.read_text().replace("throw Error('Integrate the pinned runtime data revision into this archive history before storing; preserve both histories.');","throw Error('Integrate the pinned runtime data revision into this archive history before storing; preserve both histories.',{cause:error});");p.write_text(s)
p=Path('tests/unit/library-import-atomic.test.mjs');s=p.read_text().replace('finite,{impacts=false,entities}={})','finite,{impacts=false,entities,water=false}={})');s=s.replace("entityKind:'general',names:{en:'Fixture'},schemaVersion:2,","entityKind:water?'lake':'general',names:{en:'Fixture'},schemaVersion:2,")
s+='''\ntest('water library import uses one common Core batch, preserves country identities and Undo/Redo',async t=>{
 const h=await libraryAssemblyHarness(t,true,{water:true}),before=snapshot(h),checkpoint=h.client.state().checkpoint;
 const result=await h.api.instantiate(h.entityId,'1923-01');assert.equal(result.added,1);
 assert.deepEqual(h.documentModel.snapshot().territorialEntities,before.territorialEntities);
 const water=h.documentModel.snapshot().hydroEdits.at(-1);assert.equal(water.properties.category,'lake');assert.equal(water.geometry,null);
 assert.equal(h.documentModel.snapshot().timelineRecords.parentRelations.some(row=>row.objectRef.domain==='hydro'),false);
 assert.equal(h.client.state().checkpoint,checkpoint+1);
 const after=snapshot(h);await h.project.undo();assert.deepEqual(snapshot(h),before);await h.project.redo();assert.deepEqual(snapshot(h),after);
});\n''';p.write_text(s)
for name in ['tests/fixtures/generate-timeline-exchange.mjs','tests/unit/library-data.test.mjs','tests/unit/timeline-persistence-integration.test.mjs']:
 p=Path(name);p.write_text(p.read_text().rstrip()+'\n')
