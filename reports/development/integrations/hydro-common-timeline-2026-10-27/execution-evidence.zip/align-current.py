from pathlib import Path
import re,json
p=Path('shared/frontend/js/modules/gpu-map-renderer.js');s=p.read_text(encoding='utf-8').replace('hydroEditResourceDependencies(features,baseFid) {','hydroEditResourceDependencies(features,baseFid,displayColor) {').replace('hydroDisplayColor(feature.properties.category)','displayColor(feature.properties.category)').replace('hydroEditResourceDependencies(features,baseFid);','hydroEditResourceDependencies(features,baseFid,hydroDisplayColor);');p.write_text(s,encoding='utf-8')
p=Path('apps/editor/frontend/js/modules/app-capability-ports.js');s=p.read_text(encoding='utf-8').replace('hydroSettings: Object.freeze(["colorModel",','hydroSettings: Object.freeze(["physicalResources","colorModel",');p.write_text(s,encoding='utf-8')
# All current C++ test APIs match the typed common owner. Historical source entityId remains unchanged.
for p in Path('shared/tests').glob('*.cpp'):
 s=p.read_text(encoding='utf-8');s=s.replace('.entityId','.objectRef.id')
 s=re.sub(r'(resolveWorld\([^\n;]*?\)\.find\()"([^"\n]+)"\)',r'\1territorialRef("\2"))',s)
 if p.name=='document-session-tests.cpp':
  s=s.replace('{{{"root","general"},{"child","general"}}','{{{territorialRef("root"),"general"},{territorialRef("child"),"general"}}').replace('[](const GeometryRef& ref)','[](const ObjectRef&,const GeometryRef& ref)')
  s=re.sub(r'(\{"(?:life|shape|parent):[rc]",)"(root|child)"',r'\1territorialRef("\2")',s)
  s=s.replace('replaceGeometryBindingAtMonth(records,"child",','replaceGeometryBindingAtMonth(records,territorialRef("child"),')
 if p.name=='web-territorial-command-tests.cpp':
  s=s.replace('"schemaVersion":2,"lifetimes"','"schemaVersion":3,"lifetimes"')
  s=re.sub(r'"entityId":"([^"\n]+)"',r'"objectRef":{"domain":"territorial","id":"\1"}',s)
 if p.name=='web-content-command-tests.cpp':
  s=s.replace('hydro.geometry=ref;d.hydro.push_back(hydro);','d.hydro.push_back(hydro);addStaticObjectRecords(d,{"hydro",hydro.id},ref);')
 if s!=p.read_text(encoding='utf-8'):p.write_text(s,encoding='utf-8')
# old replay is a current consumer: share common manifest, no old runtime reader
p=Path('tools/gis/replay-ussr-1922-physical.mjs');s=p.read_text(encoding='utf-8');a=s.index(' const versions=manifest?.historicalWaterbodies;');b=s.index(" for(const role of ['land','water'])",a)
s=s[:a]+''' const catalog=manifest.waterObjects;
 const binding=catalog.timelineRecords.geometryBindings.find(row=>row.objectRef.id==='waterbody:caspian'&&row.validFrom==='1922-12-30');
 verify(binding?.validTo==='1925-05-12','Unapproved historic water validity');
 const selected=catalog.geometries.find(row=>row.geometryRef.id===binding.geometryRef.id&&row.geometryRef.version===binding.geometryRef.version);
 verify(selected,'Missing selected common water geometry');
 const row={land:selected.land,water:selected.asset};
''' +s[b:]
s=s.replace('const draft=structuredClone(manifest),revision=draft.historicalWaterbodies[0];',"const draft=structuredClone(manifest),revision=draft.waterObjects.geometries.find(row=>row.asset.url.endsWith('/caspian-1922-water.json.gz'));" )
s=s.replace('const original=revision[role];','const field=role===\'water\'?\'asset\':\'land\';\n   const original=revision[field];').replace('revision[role]={...original,...assetDigest(compressed)}','revision[field]={...original,...assetDigest(compressed)}');p.write_text(s,encoding='utf-8')
p=Path('tools/build-builtin-world.mjs');s=p.read_text(encoding='utf-8').replace('input.sourceIndex.entities.map(row=>','input.sourceIndex.entities.filter(row=>![\'river\',\'lake\'].includes(row.entityType)).map(row=>');p.write_text(s,encoding='utf-8')
# Fixture render inputs are now version bound; no obsolete stored identity fields.
for p in [*Path('tests/fixtures/portability').glob('*.json'),*Path('tests/fixtures/timeline-exchange').glob('*.json')]:
 try:v=json.loads(p.read_text(encoding='utf-8'))
 except:continue
 changed=False
 def visit(value):
  global changed
  if isinstance(value,dict):
   if 'hydroEdits' in value and 'timelineRecords' in value:
    for water in value['hydroEdits']:
     props=water['properties'];metadata={k:props.pop(k) for k in ['stroke_width','stroke_widths','border_aligned','connectivity'] if k in props}
     if metadata:
      for binding in value['timelineRecords']['geometryBindings']:
       if binding['objectRef']=={'domain':'hydro','id':water['id']}:binding['rendering']=metadata
      changed=True
   for child in value.values():visit(child)
  elif isinstance(value,list):
   for child in value:visit(child)
 visit(v)
 if changed:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('current callers updated')
