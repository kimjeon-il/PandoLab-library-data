from pathlib import Path
p=Path('shared/tests/hydro-timeline-tests.cpp');s=p.read_text().replace('#include <cassert>','#include <pandoeditor/webobjectcommands.h>\n#include <cassert>');s=s.replace('int main(){','''int main(){
 {
 Project project;ProjectDocument document;document.documentId="bulk-water";
 Geometry line;line.type="LineString";line.lines={{{0,0},{1,1}}};document.geometries.insert({"river",1},line);
 HydroFeature water;water.id="r";water.kind="river";document.hydro.push_back(water);addStaticObjectRecords(document,{"hydro","r"},{"river",1});
 project.replace(document);project.setTimelineCursor("1923-01",true);
 auto request=readWebObjectRemoval(project.snapshot(),codecjson::parse(R"({"refs":[{"domain":"hydro","id":"r"}]})"));
 auto prepared=CommandProcessor::prepare(project,request);
 if(!prepared.preview){std::cerr<<"bulk delete: "<<prepared.detail<<'\\n';return 2;}
 assert(CommandProcessor::confirm(project,*prepared.preview).changed());
 assert(!project.resolveWorld("1923-01").find({"hydro","r"}));assert(project.resolveWorld("1922-12").find({"hydro","r"}));
 assert(project.undo()&&project.resolveWorld("1923-01").find({"hydro","r"}));
 }
''');p.write_text(s)
