import {readFileSync,existsSync} from 'node:fs';
import {resolve} from 'node:path';
import {execFileSync} from 'node:child_process';
import {buildFrontendSnapshot} from '../../../scripts/lib/frontend-build.mjs';
import {createP3PreviewServer} from '../../../scripts/p3-preview-server.mjs';
const root=process.cwd(),index=JSON.parse(readFileSync('.library-data/repository/archive/index.json'));
const pinned=JSON.parse(execFileSync('git',['show','68380579a7c7a1bd8ec97683b7517502c1389c3c:archive/index.json'],{cwd:'.library-data/repository',maxBuffer:16*1024*1024}));
index.files={...pinned.files,...index.files};
const snapshot=await buildFrontendSnapshot({root,readPinnedData:path=>readFileSync(resolve(root,path)),dataPaths:Object.keys(index.files).filter(path=>path.startsWith('assets/data/'))});
const assets=new Map([...snapshot.assets].map(([path,entry])=>[path,{bytes:entry.bytes}]));
for(const path of Object.keys(index.files))if(path.startsWith('assets/data/')&&existsSync(resolve(root,path)))assets.set(path,{file:resolve(root,path)});
assets.set('index.html',{bytes:Buffer.from(snapshot.html.viewer)});
assets.set('__editor/index.html',{bytes:Buffer.from(snapshot.html.editor.replace('href="../../" data-product-base="editor"','href="/" data-product-base="editor"'))});
const server=createP3PreviewServer(root,{assets:()=>assets});
server.listen(4186,'127.0.0.1',()=>console.log('Candidate Web + editor shell at http://127.0.0.1:4186, data read from current task output, no pin preparation'));
for(const signal of ['SIGINT','SIGTERM'])process.once(signal,()=>server.close(()=>process.exit(0)));

