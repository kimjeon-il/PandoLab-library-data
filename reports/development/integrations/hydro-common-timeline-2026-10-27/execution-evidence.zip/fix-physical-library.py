from pathlib import Path
p=Path('shared/frontend/js/modules/physical-resources.js');s=p.read_text(encoding='utf-8');s="import './' + '';\n"+s if False else s
s="import {geometryReferenceFor} from './geometry-version-store.js';\nimport '../vendor/polygon-clipping.min.js';\n"+s
at=s.index('export function createPhysicalResources(')
s=s[:at]+'''// Derived mask presentation belongs to the existing physical resource owner.
// Project water identity/periods remain owned by the common C++ document.
export function createPhysicalWaterPresentation() {
  let previousKey=null,previous=null;
  return (context,replacement,visible)=>{
    if(!replacement)return visible?context:{...context,water:null};
    const ref=geometryReferenceFor(replacement.geometry);
    if(!ref)throw new Error('A copied water mask requires an admitted geometry version.');
    const key=JSON.stringify([context.revision,context.waterRevision,ref.id,ref.version]);
    if(key===previousKey)return previous;
    const polygons=geometry=>geometry.type==='Polygon'?[geometry.coordinates]:geometry.coordinates;
    const extent=polygons(replacement.geometry).concat(polygons(context.water)).flat(2).reduce((box,[x,y])=>[Math.min(box[0],x),Math.min(box[1],y),Math.max(box[2],x),Math.max(box[3],y)],[Infinity,Infinity,-Infinity,-Infinity]);
    const local=[],unchanged=[];
    for(const polygon of context.geometry.coordinates){
      const box=polygon[0].reduce((b,[x,y])=>[Math.min(b[0],x),Math.min(b[1],y),Math.max(b[2],x),Math.max(b[3],y)],[Infinity,Infinity,-Infinity,-Infinity]);
      (box[0]<=extent[2]&&box[2]>=extent[0]&&box[1]<=extent[3]&&box[3]>=extent[1]?local:unchanged).push(polygon);
    }
    const filled=globalThis.polygonClipping.union(...local.map(polygon=>[polygon]),polygons(context.water));
    const changed=globalThis.polygonClipping.difference(filled,polygons(replacement.geometry));
    previousKey=key;previous=Object.freeze({...context,geometry:{type:'MultiPolygon',coordinates:[...unchanged,...changed]},revision:key,water:null});
    return previous;
  };
}
''' +s[at:]
s=s.replace('let requestedWaterKey=null;','let requestedWaterKey=null;\n  const presentPhysicalWater=createPhysicalWaterPresentation();')
s=s.replace('    return entry.value||physicalLand;','''    if(!entry.value)return physicalLand;
    const state=dependencies.projectState.state;
    const replacement=(state.hydroEdits||[]).find(feature=>feature.properties.sourceFeatureId===id);
    const feature=state.hydroFeatureCache?.get(id);
    const visible=!feature||dependencies.physicalServices.isHydroFeatureVisible(feature);
    return presentPhysicalWater(entry.value,replacement,visible);''')
p.write_text(s,encoding='utf-8')
# Preserve nested per-part river width profiles, same as published tiles and Canvas.
p=Path('shared/frontend/js/modules/gpu-map-renderer.js');s=p.read_text(encoding='utf-8').replace("const widths=feature.geometry.type==='LineString'?profile:profile?.[partIndex];","const widths=profile?.[partIndex];");p.write_text(s,encoding='utf-8')
# Existing common library descriptors carry selected rendering.
p=Path('apps/editor/frontend/js/modules/territorial-library.js');s=p.read_text(encoding='utf-8').replace('geometry: structuredClone(version.geometry), validFrom:','geometry: structuredClone(version.geometry), rendering:structuredClone(version.rendering || {}), validFrom:');p.write_text(s,encoding='utf-8')
p=Path('apps/editor/frontend/js/modules/app-library-assembly.js');s=p.read_text(encoding='utf-8').replace("category:item.entityKind,name:item.name,notes:'',editorColor:","...item.rendering,category:item.entityKind,name:item.name,notes:'',editorColor:");p.write_text(s,encoding='utf-8')
p=Path('apps/editor/frontend/js/modules/library-geometry-context.js');s=p.read_text(encoding='utf-8').replace("category:entity.entityKind,name:","...copy(version.rendering || {}),category:entity.entityKind,name:")
s=s.replace('if(water)project.hydroEdits.push({...feature,geometry:null});','''if(water){const properties={...feature.properties};for(const key of ['stroke_width','stroke_widths','border_aligned','connectivity'])delete properties[key];project.hydroEdits.push({...feature,geometry:null,properties});}''')
s=s.replace('...base,geometryRef});','...base,geometryRef,...(water&&version.rendering?{rendering:copy(version.rendering)}:{})});')
s=s.replace("{...row,geometry:copy(after.geometry)}:row", "{...row,geometry:copy(after.geometry),...(row.rendering?{rendering:Object.fromEntries(Object.entries(row.rendering).filter(([key])=>!['stroke_widths','connectivity'].includes(key)))}:{})}:row")
# Geometry-only source save permits effective removal of vertex-bound metadata, keeps all other source facts.
s=s.replace('||!same(after.properties,before.properties)',"||!same(Object.fromEntries(Object.entries(after.properties).filter(([key])=>!['stroke_widths','connectivity'].includes(key))),Object.fromEntries(Object.entries(before.properties).filter(([key])=>!['stroke_widths','connectivity'].includes(key))))")
p.write_text(s,encoding='utf-8')
# Test library rendering propagation before changing native source structs.
p=Path('tests/unit/hydro-library-history.test.mjs');s=p.read_text().replace('normalizeTerritorialLibraryEntity,selectGeometryVersion','normalizeTerritorialLibraryEntity,selectGeometryVersion,instantiateLibraryEntity');s=s.replace("geometry:kind==='river'?{type:'LineString',coordinates:[[0,0],[2,1]]}:polygon(3)","rendering:kind==='river'?{stroke_widths:[[2,3]],connectivity:{node:'b'}}:{},geometry:kind==='river'?{type:'LineString',coordinates:[[0,0],[2,1]]}:polygon(3)");s=s.replace("assert.equal(workspace.project.hydroEdits.length,1);","assert.equal(workspace.project.hydroEdits.length,1);\n  assert.deepEqual(instantiateLibraryEntity(source,'1922-12-30').rendering,source.geometryVersions[1].rendering);\n  assert.deepEqual(workspace.project.timelineRecords.geometryBindings[0].rendering,source.geometryVersions[1].rendering);")
p.write_text(s)
for name in ['hydro-common-document.test.mjs','hydro-resource-history.test.mjs']:
 p=Path('tests/unit')/name;s=p.read_text();s=s.replace('stroke_widths:[1,2]','stroke_widths:[[1,2]]').replace('stroke_widths:[2,3,4]','stroke_widths:[[2,3,4]]').replace('stroke_widths:[2,3]','stroke_widths:[[2,3]]');s=s.replace('.properties.stroke_widths,[2,3,4]', '.properties.stroke_widths,[[2,3,4]]').replace('.properties.stroke_widths,[1,2]', '.properties.stroke_widths,[[1,2]]').replace('.rendering.stroke_widths,[2,3,4]', '.rendering.stroke_widths,[[2,3,4]]');p.write_text(s)
print('source replacement and library rendering wired')
