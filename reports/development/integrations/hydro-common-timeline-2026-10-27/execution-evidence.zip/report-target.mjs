import {reportPath} from '../../../tools/report-paths.mjs';
console.log(reportPath('reports/development/integrations/hydro-common-timeline-2026-10-27/README.md',{root:process.cwd(),access:'write'}));
