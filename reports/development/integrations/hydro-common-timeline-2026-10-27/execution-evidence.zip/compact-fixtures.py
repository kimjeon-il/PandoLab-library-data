from pathlib import Path
import json
for name in ['timeline-records.json','timeline-storage.json']:
 p=Path('tests/fixtures')/name;v=json.loads(p.read_text())
 rows=[]
 for key,value in v.items():
  if key=='cases':rows.append(json.dumps(key)+':[');rows.extend(json.dumps(row,ensure_ascii=False,separators=(',',':'))+(',' if i<len(value)-1 else '') for i,row in enumerate(value));rows.append(']')
  else:rows.append(json.dumps(key)+':'+json.dumps(value,ensure_ascii=False,separators=(',',':'))+',')
 p.write_text('{\n'+'\n'.join(rows)+'\n}\n',encoding='utf-8')
