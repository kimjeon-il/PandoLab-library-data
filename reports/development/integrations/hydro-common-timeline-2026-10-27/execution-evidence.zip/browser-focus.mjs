import {chromium} from '@playwright/test';
import fs from 'node:fs';
import assert from 'node:assert/strict';
const browser=await chromium.launch({channel:'msedge',headless:true,args:['--use-angle=d3d11']});
const results=[];
try{
 for(const product of ['viewer','editor']){
  const context=await browser.newContext({viewport:{width:1280,height:900}}),page=await context.newPage();
  const errors=[],failed=[];page.on('pageerror',error=>errors.push(error.message));page.on('response',response=>{if(response.status()>=400)failed.push({url:response.url(),status:response.status()});});
  const file=product==='viewer'?'viewer-composition.js':'app-composition.js';
  await page.route('**/modules/'+file+'*',async route=>{
   const response=await route.fetch();let source=await response.text();
   const anchor=product==='viewer'?"  const lifecycle=createApplicationLifecycle(":'        if (onComposed) await onComposed(';
   assert.ok(source.includes(anchor));
   const hook=product==='viewer'?"window.__waterProof={setMonth:month=>builtinClock.selectMonth(month),state:()=>map.viewState,physical:owners.physicalResources,focus:()=>map.navigation.focusCoordinate([51,41],5)};":"window.__waterProof={setMonth:month=>domainAssembly.setTimelineMonth(month),state:()=>projectSession.state,physical:physicalResources,focus:()=>cameraNavigation.focusCoordinate([51,41],5)};";
   await route.fulfill({contentType:'text/javascript',body:source.replace(anchor,hook+'\n'+anchor)});
  });
  await page.goto('http://127.0.0.1:4186/'+(product==='viewer'?'?debug=1':'__editor/index.html'),{waitUntil:'domcontentloaded'});
  await page.waitForFunction(()=>window.__waterProof && window.__waterProof.state().timelineCursor,{timeout:90000});
  await page.evaluate(()=>window.__waterProof.focus());
  const rows=[];
  for(const month of ['1925-04','1925-05']){
   await page.evaluate(month=>window.__waterProof.setMonth(month),month);
   await page.waitForFunction(month=>{const proof=window.__waterProof,value=proof.physical.physicalLand;return proof.state().timelineCursor===month&&value?.water&&proof.state().hydroFeatureCache.get('waterbody:caspian')?.geometry===value.water;},month,{timeout:45000});
   await page.waitForTimeout(1500);
   await page.screenshot({path:'.superpowers/sdd/hydro-common-timeline/'+product+'-caspian-'+month+'.png'});
   rows.push(await page.evaluate(()=>{const proof=window.__waterProof,value=proof.physical.physicalLand;return{month:proof.state().timelineCursor,waterRevision:value.waterRevision,landRevision:value.revision,cacheCount:[...proof.state().hydroFeatureCache.keys()].filter(id=>id==='waterbody:caspian').length};}));
  }
  await page.screenshot({path:'.superpowers/sdd/hydro-common-timeline/'+product+'-water.png'});
  assert.notEqual(rows[0].waterRevision,rows[1].waterRevision);assert.ok(rows.every(row=>row.cacheCount===1));
  results.push({product,rows,errors,failed});fs.writeFileSync('.superpowers/sdd/hydro-common-timeline/browser-focus.json',JSON.stringify(results,null,2));
  assert.deepEqual(errors,[]);assert.deepEqual(failed,[]);
  await context.close();console.log(product+' common water rendering and single source identity passed');
 }
}finally{await browser.close();}

