from pathlib import Path
p=Path('shared/core/src/projectcodec.cpp');s=p.read_text().replace('document.geometries.get(ref)!=nullptr;}},month);','document.geometries.get(ref)!=nullptr;}},snapshot.timelineMonth());');p.write_text(s)
p=Path('shared/frontend/js/modules/core-document-read-model.js');s=p.read_text();s=s.replace('let territorialViews = Object.freeze([]);','let territorialViews = Object.freeze([]);\n  let hydroViews = Object.freeze([]);');s=s.replace('territorialViews=Object.freeze([]);','territorialViews=Object.freeze([]);hydroViews=Object.freeze([]);');s=s.replace("if(domain==='hydro' && world)return world.entities.filter(row=>row.objectRef.domain==='hydro').map(row=>freeze({...row.identity,geometry:row.geometry}));","if(domain==='hydro' && world)return hydroViews;")
s=s.replace('const projected = freeze({ ...structuredClone(row), id:row.objectRef.id, identity: projectTimelineIdentity(identity, row.properties), geometry });','const temporalIdentity=projectTimelineIdentity(identity,row.properties);\n      const effectiveIdentity=row.objectRef.domain===\'hydro\'?freeze({...temporalIdentity,properties:{...temporalIdentity.properties,...row.rendering}}):temporalIdentity;\n      const projected = freeze({ ...structuredClone(row), id:row.objectRef.id, identity:effectiveIdentity, geometry });')
s=s.replace('function viewsForWorld(nextWorld) {','function viewsForWorld(nextWorld,domain=\'territorial\') {\n    const oldViews=domain===\'hydro\'?hydroViews:territorialViews;');s=s.replace("filter(row=>row.objectRef.domain==='territorial').map((row,index) => [row.id,{ row,view: territorialViews[index] }])","filter(row=>row.objectRef.domain===domain).map((row,index) => [row.id,{ row,view: oldViews[index] }])");s=s.replace("nextWorld.entities.filter(row=>row.objectRef.domain==='territorial')","nextWorld.entities.filter(row=>row.objectRef.domain===domain)");s=s.replace('return freeze({ ...row.identity,geometry: row.geometry,properties:',"if(domain==='hydro')return freeze({...row.identity,geometry:row.geometry});\n      return freeze({ ...row.identity,geometry: row.geometry,properties:")
s=s.replace('return nextViews;','return nextViews.length===oldViews.length&&nextViews.every((row,i)=>row===oldViews[i])?oldViews:nextViews;');s=s.replace('const nextViews=viewsForWorld(nextWorld);','const nextViews=viewsForWorld(nextWorld);\n    const nextHydroViews=viewsForWorld(nextWorld,\'hydro\');');s=s.replace('territorialViews=nextViews;','territorialViews=nextViews;hydroViews=nextHydroViews;');s=s.replace('objectRef,geometryRef,parentId,coverageMode,validFrom,validTo,rootId,ancestors,properties','objectRef,geometryRef,rendering,parentId,coverageMode,validFrom,validTo,rootId,ancestors,properties');p.write_text(s)
# Resource owner uses immutable version inputs; no coordinate hash or global document revision.
p=Path('shared/frontend/js/modules/gpu-map-renderer.js');s=p.read_text();s="import { geometryReferenceFor } from './geometry-version-store.js';\n"+s
pos=s.index('\n',s.index("import { resourceKey, resourceUpdate }"))+1
s=s[:pos]+'''\nexport function hydroEditResourceDependencies(features,baseFid) {
  const rows=features.filter(feature=>feature.geometry).map(feature=>{
    const ref=geometryReferenceFor(feature.geometry);
    if(!ref)throw new Error('Hydro rendering requires an admitted geometry version.');
    return {id:feature.id,ref,category:feature.properties.category,rendering:feature.properties.stroke_widths || null,
      width:feature.properties.stroke_width || 1,aligned:feature.properties.border_aligned===true,
      color:feature.properties.editorColor || hydroDisplayColor(feature.properties.category)};
  });
  return {source:'common-object-geometry',content:resourceKey(rows.map(({id,ref,category})=>({id,ref,category}))),
    preparation:resourceKey({algorithm:1,baseFid,rows:rows.map(({id,ref,category,...inputs})=>inputs)}),context:null,presentation:'hydro-edits'};
}
''' +s[pos:]
s=s.replace('let hydroEditSource = null;','let hydroEditDependencies = null;\n    let hydroEditGeneration=0;');s=s.replace('setHydroEdits(state.hydroEdits || [], Number(state.stateRevision || 0))','setHydroEdits(state.hydroEdits || [])')
s=s.replace('for (const part of hydroLineParts(feature.geometry)) for (let index', 'for (const [partIndex,part] of hydroLineParts(feature.geometry).entries()) for (let index')
s=s.replace('startWidths.push(width); endWidths.push(width);','const profile=feature.properties?.stroke_widths;\n            const widths=feature.geometry.type===\'LineString\'?profile:profile?.[partIndex];\n            startWidths.push(Number(widths?.[index] ?? width)); endWidths.push(Number(widths?.[index+1] ?? width));')
a=s.index('    function setHydroEdits(');b=s.index('      const entries = [];',a)
s=s[:a]+'''    function setHydroEdits(features = []) {
      const baseFid = Math.max(0, Number(hydroPreparation.manifest?.stats?.featureCount || 0));
      const dependencies=hydroEditResourceDependencies(features,baseFid);
      const rebuild=resourceUpdate(hydroEditDependencies,dependencies).prepare;
      // Picking follows current presentation metadata even when the mesh is reusable.
      if(!rebuild){
        const byId=new Map(features.map(feature=>[feature.id,feature]));
        for(const [fid,feature] of hydroEditFeatureByFid)hydroEditFeatureByFid.set(fid,byId.get(feature.id));
        return false;
      }
''' +s[b:]
s=s.replace('      const baseFid = Math.max(0, Number(hydroPreparation.manifest?.stats?.featureCount || 0));\n      let nextFid', '      let nextFid');s=s.replace('hydroPreparation.replaceEdits(entries, nextRevision);\n      hydroEditSource = features;','hydroPreparation.replaceEdits(entries, ++hydroEditGeneration);\n      hydroEditDependencies = dependencies;');p.write_text(s)
p=Path('shared/frontend/js/modules/map-content-presentation.js');s=p.read_text().replace('state.hydroEdits || [], hydro.getStateRevision?.() || state.stateRevision','state.hydroEdits || []');p.write_text(s)
# New required port follows existing capability wiring.
p=Path('apps/editor/frontend/js/modules/app-capability-ports-foundation.js');s=p.read_text().replace('physicalResources: Object.freeze([[','physicalResources: Object.freeze([["isHydroObjectActive","physicalResources","isHydroObjectActive"],[');p.write_text(s)
print('read projection and resource inputs wired')
