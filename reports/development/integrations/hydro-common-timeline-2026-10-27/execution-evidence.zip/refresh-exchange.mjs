import {readFile,writeFile} from 'node:fs/promises';
import {productionGeoPackage,coreFileProjection} from '../../../tests/helpers/production-geopackage.mjs';
for(const kind of ['static','complex','calendar-boundaries']){
 const path='tests/fixtures/timeline-exchange/'+kind;
 const project=JSON.parse(await readFile(path+'.json','utf8'));
 const receipt=await coreFileProjection(project);
 const output=await productionGeoPackage('write',new ArrayBuffer(0),receipt.project,receipt.spatialState);
 await writeFile(path+'.gpkg',new Uint8Array(output.buffer));
 console.log(kind+' current common timeline fixture written');
}
