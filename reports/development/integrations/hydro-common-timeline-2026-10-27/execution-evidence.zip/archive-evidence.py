from pathlib import Path
import json,subprocess,zipfile,hashlib,os
scratch=Path('.superpowers/sdd/hydro-common-timeline')
report=Path('D:/dev/PandoLab-library-data/reports/.edits/objects/development/integrations/hydro-common-timeline-2026-10-27')
files=subprocess.check_output(['git','show','--format=','--name-only','HEAD'],text=True,encoding='utf-8').strip()
(report/'changed-code-files.txt').write_text(files+'\n',encoding='utf-8')
summary={
 'appCommit':'e5cb51a6e158f7ef0aed4a3dedaf03f691c81c63','appRemoteBranch':'work/objects','appRemoteSha':'c3cd830c7c5b5f328d1f9ac590d218621231f191',
 'runtimeLocalArchiveCommit':'bd7e4eba99cbf71bf4713761a955b396a98ce6a5','runtimePinUnchanged':'68380579a7c7a1bd8ec97683b7517502c1389c3c','runtimeRemoteSha':'ea843c09e790245cbcfe35a44051b2d67534ee4e',
 'runtimeStatus':'pending user decision on existing data work/objects history integration; local archive is not a publishable paired pin',
 'wasm':json.loads(Path('shared/frontend/static/wasm/pandoeditor-core.manifest.json').read_text()),
 'caspian':json.loads((scratch/'caspian-check.json').read_text()),
 'browser':json.loads((scratch/'browser-proof.json').read_text()),'browserCloseup':json.loads((scratch/'browser-focus.json').read_text()),
 'retainedGenerated':{'emsdkBytes':1970577553,'pythonToolsBytes':84851345,'incrementalWasmBuildBytes':29159600},
 'cleanup':{'sdkDownloadFiles':0,'notes':'SDK and fixed incremental build remain current build dependencies. Task scratch is archived losslessly before scoped cleanup; data materialization remains task WIP pending paired-pin integration.'}}
(report/'evidence.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
manifest=[]
with zipfile.ZipFile(report/'execution-evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as archive:
 for path in sorted(scratch.iterdir()):
  if path.is_file():
   body=path.read_bytes();manifest.append({'path':path.name,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()});archive.writestr(path.name,body)
with zipfile.ZipFile(report/'execution-evidence.zip') as archive:
 for entry in manifest:assert hashlib.sha256(archive.read(entry['path'])).hexdigest()==entry['sha256']
receipt={'files':manifest,'logicalBytes':sum(row['bytes'] for row in manifest),'compressedBytes':(report/'execution-evidence.zip').stat().st_size,'sha256':hashlib.sha256((report/'execution-evidence.zip').read_bytes()).hexdigest()}
(report/'execution-evidence-manifest.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k!='files'}))
