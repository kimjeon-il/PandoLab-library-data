import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {gunzipSync} from 'node:zlib';
import assert from 'node:assert/strict';
import {resolvePhysicalWaterObjects,createPhysicalResources} from '../../../shared/frontend/js/modules/physical-resources.js';
const root=process.cwd(),base='assets/data/physical-land/v1/';
const manifest=JSON.parse(fs.readFileSync(base+'manifest.json'));
const source=JSON.parse(fs.readFileSync('assets/data/territorial-entities/source/countries/waterbody-caspian.json'));
assert.equal(source.entityId,'waterbody:caspian');
assert.deepEqual(source.geometryVersions.map(row=>[row.validFrom,row.validTo]),[[null,'1922-12-29'],['1922-12-30','1925-05-12'],['1925-05-13',null]]);
const approved=JSON.parse(fs.readFileSync('D:/dev/PandoLab-library-data/reports/.edits/objects/development/integrations/hydro-common-timeline-2026-10-27/approved-physical-manifest.json'));
const receipts=[];
for(const name of ['geometry.json.gz','caspian-1922-land.json.gz','caspian-1922-water.json.gz']){
 const bytes=fs.readFileSync(base+name),sha256=createHash('sha256').update(bytes).digest('hex');
 const expected=name==='geometry.json.gz'?approved.asset:approved.historicalWaterbodies[0][name.includes('-land')?'land':'water'];assert.equal(sha256,expected.sha256);
 receipts.push({name,sha256,bytes:bytes.length});
}
let requests=0;
globalThis.PANDOLAB_BUILD_META={dataRevision:'candidate-water-history',physicalLand:manifest.asset,physicalWaterObjects:manifest.waterObjects};
globalThis.fetch=async input=>{requests++;const file=new URL(input).pathname.replace(/^\//,'');return new Response(fs.readFileSync(file));};
const state={timelineCursor:'1922-12-29'},events=[];
const resources=createPhysicalResources({capabilities:{terrain:false,builtinHydro:false}});
resources.connect({projectState:{state},physicalConfig:{PHYSICAL_DATA_BASE_URL:'http://candidate/assets/data/'},domains:{renderingDomain:{invalidateProject:reason=>events.push(reason)}},feedback:{reportOperationError:error=>{throw error;}}});
await resources.loadPhysicalData({includeHydro:false});
const cases=[];let previousKey=null,previousResource=null;
for(const date of ['1922-12-29','1922-12-30','1925-05-12','1925-05-13']){
 state.timelineCursor=date;
 const selected=resolvePhysicalWaterObjects(manifest.waterObjects,date);assert.equal(selected.length,1);
 const key=selected[0].geometryRef.id;
 let value;
 for(let attempt=0;attempt<50;attempt++){value=resources.physicalLand;if(value?.waterRevision===selected[0].assets.asset.sha256)break;await new Promise(resolve=>setTimeout(resolve,10));}
 assert.equal(value.waterRevision,selected[0].assets.asset.sha256);assert.equal(value.revision,selected[0].assets.land.sha256);
 assert.deepEqual(value.waterObjectRef,{domain:'hydroBuiltin',id:'waterbody:caspian'});
 if(key===previousKey)assert.equal(value,previousResource);
 const polygons=value.water.type==='Polygon'?[value.water.coordinates]:value.water.coordinates;
 const holes=polygons.reduce((n,p)=>n+p.length-1,0),vertices=polygons.flat().reduce((n,r)=>n+r.length,0);
 if(date>='1922-12-30'&&date<='1925-05-12')assert.equal(holes,68);
 cases.push({date,geometryRef:selected[0].geometryRef,waterSha256:value.waterRevision,landSha256:value.revision,holes,vertices,requests});previousKey=key;previousResource=value;
}
assert.equal(cases[1].requests,cases[2].requests,'same history does not download again');
assert.equal(cases[0].waterSha256,cases[3].waterSha256);
console.log(JSON.stringify({scope:['waterbody:caspian','direct physical assets'],receipts,cases,requests,events},null,2));
