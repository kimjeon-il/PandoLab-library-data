from pathlib import Path
p=Path('tools/library-data.mjs');s=p.read_text();a=s.index('function storeOwnedLibraryData(');b=s.index('  const runtimeDirectories',a);start=s.index('  const index = JSON.parse',a)
s=s[:start]+'''  // A runtime pin owns all unselected data inputs, independently of the
  // archive checkout's later report or other stored work.
  const index = JSON.parse(reportData?readFileSync(indexPath,'utf8'):git(data.checkout,['show',`${libraryConfig(root).revision}:archive/index.json`],{allowFetch:true}));
  const publicationBranch=reportData?'main':git(root,['symbolic-ref','--short','HEAD']);
  if(!publicationBranch)throw Error('Runtime publication requires an explicit application branch.');
  index.branch=publicationBranch;
''' +s[b:]
s=s.replace("`HEAD:${reportData ? 'main' : index.branch}`","`HEAD:${publicationBranch}`").replace("const branch = reportData ? 'main' : index.branch;","const branch = publicationBranch;")
p.write_text(s)
