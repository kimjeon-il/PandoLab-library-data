from pathlib import Path
p=Path('tools/library-data.mjs');s=p.read_text();needle="  const index = JSON.parse(reportData?readFileSync(indexPath,'utf8'):git(data.checkout,['show',`${libraryConfig(root).revision}:archive/index.json`],{allowFetch:true}));"
s=s.replace(needle,'''  if(!reportData)try { git(data.checkout,['merge-base','--is-ancestor',libraryConfig(root).revision,'HEAD']); }
  catch(error){if(error.status!==1)throw error;throw Error('Integrate the pinned runtime data revision into this archive history before storing; preserve both histories.');}
'''+needle);p.write_text(s)
p=Path('tests/unit/library-data.test.mjs');s=p.read_text();needle="  mkdirSync(remote);git(remote,'init','--bare','-q');\n  const path='assets/data/value.bin', bytes=Buffer.from('first');";s=s.replace(needle,"  git(root,'branch','-m','main');\n"+needle);p.write_text(s)
