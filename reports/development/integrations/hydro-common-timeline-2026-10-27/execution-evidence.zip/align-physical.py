from pathlib import Path
p=Path('apps/viewer/js/modules/viewer-map.js');s=p.read_text(encoding='utf-8').replace('physicalSettings.connect({projectState:','physicalSettings.connect({physicalResources,projectState:');p.write_text(s,encoding='utf-8')
p=Path('tests/unit/ussr-1922-physical-replay.test.mjs');s=p.read_text();a=s.index('const manifest=assets=>(');b=s.index("test('original",a)
s=s[:a]+'''const manifest=assets=>({waterObjects:{timelineRecords:{geometryBindings:[{objectRef:{domain:'hydroBuiltin',id:'waterbody:caspian'},validFrom:'1922-12-30',validTo:'1925-05-12',geometryRef:{id:'caspian-near1922-approved',version:1}}]},geometries:[{geometryRef:{id:'caspian-near1922-approved',version:1},
 land:{url:SOURCE+'caspian-1922-land.json.gz',...assetDigest(assets['caspian-1922-land.json.gz'])},
 asset:{url:SOURCE+'caspian-1922-water.json.gz',...assetDigest(assets['caspian-1922-water.json.gz'])}}]}});

''' +s[b:]
s=s.replace("verifyPublishedPhysicalManifest(m,assets).id,'caspian-near1922-approved'","verifyPublishedPhysicalManifest(m,assets).water.sha256,assetDigest(assets['caspian-1922-water.json.gz']).sha256")
s=s.replace('copy.historicalWaterbodies[0].water','copy.waterObjects.geometries[0].asset').replace('wrong.historicalWaterbodies[0].validFrom','wrong.waterObjects.timelineRecords.geometryBindings[0].validFrom').replace('manifestCandidate.historicalWaterbodies[0].water','manifestCandidate.waterObjects.geometries[0].asset');p.write_text(s)
p=Path('tools/gis/replay-ussr-1922-physical.mjs');s=p.read_text().replace("verify(binding?.validTo==='1925-05-12'","verify(binding?.validFrom==='1922-12-30'&&binding?.validTo==='1925-05-12'");p.write_text(s)
p=Path('tests/unit/product-assets.test.mjs');s=p.read_text().replace("historicalWaterbodies:[{land:{url:'assets/data/physical-land/v1/historical-land.gz'},water:{url:'assets/data/physical-land/v1/historical-water.gz'}}]","waterObjects:{geometries:[{land:{url:'assets/data/physical-land/v1/historical-land.gz'},asset:{url:'assets/data/physical-land/v1/historical-water.gz'}}]}");p.write_text(s)
p=Path('apps/editor/tests/stage.test.mjs');s=p.read_text(encoding='utf-8').replace('row.entityId','row.objectRef.id').replace('physicalWaterHistory:[context]','physicalWaterObjects:{geometries:[{land:context.land,asset:context.water}]}').replace('historicalWaterbodies:[context]','waterObjects:{geometries:[{land:context.land,asset:context.water}]}');p.write_text(s,encoding='utf-8')
# Source selection carries per-version rendering through existing common binding contract.
for name in ['apps/editor/frontend/js/modules/library-geometry-context.js','apps/editor/frontend/js/modules/app-library-assembly.js']:
 p=Path(name);s=p.read_text(encoding='utf-8');p.write_text(s,encoding='utf-8')
print('physical callers and fixtures aligned')
