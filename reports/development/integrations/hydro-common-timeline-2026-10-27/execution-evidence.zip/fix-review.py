from pathlib import Path
p=Path('shared/core/src/commands.cpp');s=p.read_text().replace('require(ref.domain=="territorial" && (created?','require((ref.domain=="territorial"||ref.domain=="hydro") && (created?');p.write_text(s)
p=Path('shared/core/src/webobjectcommands.cpp');s=p.read_text();s=s.replace('#include <pandoeditor/', '#include <pandoeditor/',1)
if '#include <pandoeditor/timeline-edit.h>' not in s:s='#include <pandoeditor/timeline-edit.h>\n'+s
s=s.replace('void restoreHydroSources(ProjectDocument& candidate,const std::set<std::string>& sourceIds) {','void restoreHydroSources(ProjectDocument& candidate,const std::set<std::string>& sourceIds,const std::string& month) {\n    const auto world=resolveWorld(candidate.timelineRecords,{timelineEntityCatalog(candidate),[&](const ObjectRef&,const GeometryRef& ref){return candidate.geometries.get(ref)!=nullptr;}},month);')
s=s.replace('return row.sourceFeatureId==id;','return row.sourceFeatureId==id&&world.find({"hydro",row.id});')
s=s.replace('erase(candidate.genericFeatures,removed["generic"]);erase(candidate.hydro,removed["hydro"]);erase(candidate.labels,removed["label"]);','''erase(candidate.genericFeatures,removed["generic"]);erase(candidate.labels,removed["label"]);
    std::set<std::string> retiredWater;
    for(const auto& id:removed["hydro"]) {
        const ObjectRef ref{"hydro",id};
        if(snapshot.timelineEditsEnabled()||!isStaticTimeline(before))candidate.timelineRecords=truncateTimelineEntityAtMonth(candidate.timelineRecords,ref,snapshot.timelineMonth());
        else removeObjectTimelineRecords(candidate,ref);
        if(std::none_of(candidate.timelineRecords.lifetimes.begin(),candidate.timelineRecords.lifetimes.end(),[&](const auto& row){return row.objectRef==ref;}))retiredWater.insert(id);
    }
    erase(candidate.hydro,retiredWater);''')
s=s.replace('restoreHydroSources(candidate,hydroSources);','restoreHydroSources(candidate,hydroSources,snapshot.timelineMonth());')
s=s.replace('if(ref.domain!="territorial") {','if(ref.domain!="territorial"&&(ref.domain!="hydro"||retiredWater.count(ref.id))) {');p.write_text(s)
# Align native test registration for normal selected runs; not enabling all BUILD_TESTING.
p=Path('shared/tests/CMakeLists.txt');s=p.read_text();s+='''\nadd_executable(hydro_timeline_tests hydro-timeline-tests.cpp)
target_link_libraries(hydro_timeline_tests PRIVATE Pandoeditor::Core)
if(MSVC)
    target_compile_options(hydro_timeline_tests PRIVATE /UNDEBUG)
else()
    target_compile_options(hydro_timeline_tests PRIVATE -UNDEBUG)
endif()
add_test(NAME hydro_timeline_tests COMMAND hydro_timeline_tests)
set_tests_properties(hydro_timeline_tests PROPERTIES TIMEOUT 10)
''';p.write_text(s)
# Helpers construct current fixtures directly from frozen old fixture factories; no product compatibility path.
p=Path('tests/helpers/timeline-project.mjs');s=p.read_text();s=s.replace('input.timelineRecords.schemaVersion=2;','input.timelineRecords.schemaVersion=3;\n  for(const rows of [input.timelineRecords.lifetimes,input.timelineRecords.geometryBindings,input.timelineRecords.parentRelations])for(const row of rows){row.objectRef={domain:\'territorial\',id:row.entityId};delete row.entityId;}');s=s.replace('row.entities.map(({ id, entityKind }) =>','row.entities.map(({ objectRef:{id}, entityKind }) =>');p.write_text(s)
p=Path('tests/unit/territorial-timeline-storage.test.mjs');s=p.read_text().replace('schemaVersion:2,objectRef:{domain:"territorial",id:\'state:synthetic\'}','schemaVersion:2,entityId:\'state:synthetic\'').replace('records:{schemaVersion:1,','records:{schemaVersion:3,propertyBindings:[],').replace('saved.schemaVersion,10','saved.schemaVersion,14').replace('saved.timelineRecords.schemaVersion,1','saved.timelineRecords.schemaVersion,3');p.write_text(s)
