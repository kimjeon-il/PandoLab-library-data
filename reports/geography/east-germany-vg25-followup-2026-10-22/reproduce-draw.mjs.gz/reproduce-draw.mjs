import {pathToFileURL} from 'node:url';
import fs from 'node:fs';
import path from 'node:path';
import {chromium} from '@playwright/test';
import {libraryReportRoot} from '../../../tools/library-data.mjs';
const out=path.join(libraryReportRoot(),'geography/east-germany-vg25-followup-2026-10-22');
const before=JSON.parse(fs.readFileSync(path.join(out,'before-source.json'))).geometryVersions[0].geometry;
const after=JSON.parse(fs.readFileSync('assets/data/territorial-entities/source/countries/state-deutsche-demokratische-republik.json')).geometryVersions[0].geometry;
const recipe=JSON.parse(fs.readFileSync('tools/historical-library/east-germany-1989.recipe.json'));
const W=760,H=450;
function panel(geometry,cx,cy,scale,{overlay=false,markers=false}={}){
 const point=([x,y])=>[(x-cx)*scale+W/2,(cy-y)*scale+H/2];
 const draw=g=>g.coordinates.map(poly=>poly.map(ring=>ring.map((v,i)=>`${i?'L':'M'}${point(v).map(n=>n.toFixed(3)).join(',')}`).join('')+'Z').join('')).join('');
 const grid=[];
 const interval=scale>1000?.02:scale>300?.2:1;
 for(let x=Math.ceil((cx-W/2/scale)/interval)*interval;x<cx+W/2/scale;x+=interval){const px=point([x,cy])[0];grid.push(`<path d="M${px},0V${H}"/><text x="${px+4}" y="${H-12}">${x.toFixed(2)}°E</text>`);}
 for(let y=Math.ceil((cy-H/2/scale)/interval)*interval;y<cy+H/2/scale;y+=interval){const py=point([cx,y])[1];grid.push(`<path d="M0,${py}H${W}"/><text x="5" y="${py-5}">${y.toFixed(2)}°N</text>`);}
 const boxes=markers?recipe.boundarySupplement.sections.map(s=>{const [a,b,c,d]=s.bounds,[x,y]=point([a,d]),[x2,y2]=point([c,b]);return `<rect x="${x}" y="${y}" width="${x2-x}" height="${y2-y}" fill="none" stroke="#13764d" stroke-width="2" stroke-dasharray="8 5"/>`}).join('')+
 [['엘베·노이하우스 보류',[10.25,52.7,11.9,53.44]],['튀링겐·하르츠 등 보류',[9.75,50.15,11.95,51.85]]].map(([label,[a,b,c,d]])=>{const [x,y]=point([a,d]),[x2,y2]=point([c,b]);return `<rect x="${x}" y="${y}" width="${x2-x}" height="${y2-y}" fill="#cf891b" fill-opacity=".07" stroke="#bc7913" stroke-dasharray="5 5"/><text x="${x}" y="${y-5}" font-size="14" fill="#925b0c">${label}</text>`}).join(''):'';
 return `<svg viewBox="0 0 ${W} ${H}"><defs><clipPath id="clip"><rect width="${W}" height="${H}"/></clipPath></defs><rect width="${W}" height="${H}" fill="#f6f8f9"/><g clip-path="url(#clip)"><g fill="#7b8794" stroke="#dce3e8" stroke-width="1" font-size="12">${grid.join('')}</g><path d="${draw(geometry)}" fill="${overlay?'none':'#cadff0'}" stroke="#1463a0" stroke-width="1.6" fill-rule="evenodd"/>${overlay?`<path d="${draw(before)}" fill="none" stroke="#d06a19" stroke-width="1.6" stroke-dasharray="6 4"/>`:''}${boxes}</g><rect x=".5" y=".5" width="${W-1}" height="${H-1}" fill="none" stroke="#acbac5"/></svg>`;
}
function sheet(id,title,cx,cy,scale,note,{markers=false}={}){
 return `<section id="${id}"><h1>${title}</h1><p>${note}</p><div class="grid">${['기존판','수정판','중첩 비교'].map((label,i)=>`<article><h2>${label}</h2>${panel(i===0?before:after,cx,cy,scale,{overlay:i===2,markers})}</article>`).join('')}</div><footer>1989-04-25 동독 자료 · 세 패널 동일 중심 (${cx}, ${cy}) / 동일 배율 (${scale.toFixed(2)}px/°) / 패널 ${W}×${H}px · 파랑: 국가 경계 · 주황 점선: 기존 경계 · 독립 역사 벡터에 대한 0.5px 검증 아님</footer></section>`;
}
const html=`<!doctype html><meta charset="utf-8"><style>body{margin:0;background:#edf1f4;font-family:"Malgun Gothic",sans-serif;color:#142536}section{width:2380px;padding:28px;background:white;margin:16px 0;box-sizing:border-box}h1{font-size:28px;margin:0 0 10px}p{font-size:19px;margin:0 0 18px;color:#405669}h2{font-size:22px;margin:0 0 8px}article{width:760px}svg{width:760px;height:450px;display:block}.grid{display:flex;gap:16px}footer{font-size:16px;line-height:1.7;margin-top:14px;color:#526475}</style>`+
 sheet('comparison-bavaria','추가 VG25 — 바이에른 접경',10.95,50.4,2560*64/360,'왼쪽: 직전 LSIB·샤알제 수정판 / 가운데: 이번 추가판 / 오른쪽: 중첩. 바이에른 중앙부를 같은 중심·배율로 비교.')+
 sheet('comparison-eichsfeld','추가 VG25 — 북부 아이히스펠트',10.16,51.55,1800,'변화 확인용 확대도. 남쪽 벤데바흐·베라 구간까지 동일성을 확대 주장하지 않음.')+
 sheet('comparison-ecker','추가 VG25 — 에커강과 댐',10.61,51.84,2200,'변화 확인용 확대도. 국립공원·측량기관 문헌으로 확인한 에커 구간에 제한.')+
 sheet('comparison-geismar','추가 VG25 — 가이스마르·슈팔',9.925,50.66,3400,'변화 확인용 확대도. 공식 토지정리도에서 확인한 구간만 적용; 북쪽 포인트 알파는 포함하지 않음.');
const file='.superpowers/sdd/ddr-vg25-followup/comparison.html';fs.writeFileSync(file,html);
const browser=await chromium.launch({channel:'msedge',headless:true,args:['--use-angle=d3d11']});
try{const page=await browser.newPage({viewport:{width:2400,height:1000},deviceScaleFactor:1});
 await page.goto(pathToFileURL(path.resolve(file)).href);
 for(const id of ['comparison-bavaria','comparison-eichsfeld','comparison-ecker','comparison-geismar'])await page.locator('#'+id).screenshot({path:path.join(out,id+'.png')});
}finally{await browser.close();}
console.log(out);
