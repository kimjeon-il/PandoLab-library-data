import {spawn} from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {chromium,expect} from '@playwright/test';
import {libraryReportRoot} from '../../../tools/library-data.mjs';
const out=path.join(libraryReportRoot(),'geography/east-germany-vg25-followup-2026-10-22');
const packagePath=path.resolve('.superpowers/sdd/ddr-vg25-followup/DDR-1989-source-review.gpkg');
const bytes=gunzipSync(fs.readFileSync(path.join(out,'app-export.gpkg.gz')));
fs.writeFileSync(packagePath,bytes);
const source=JSON.parse(fs.readFileSync('assets/data/territorial-entities/source/countries/state-deutsche-demokratische-republik.json'));
const sourceGeometry=source.geometryVersions[0].geometry;
const attachments='.superpowers/sdd/ddr-vg25-followup/browser-results-fixed/historical-library-East-Ge-3759e-history-and-original-source/attachments';
const proofFile=fs.readdirSync(attachments).find(name=>name.startsWith('static-import-provenance-')&&name.endsWith('.json'));
const app=JSON.parse(fs.readFileSync(path.join(attachments,proofFile)));
fs.copyFileSync(path.join(attachments,proofFile),path.join(out,'app-import-undo-redo-proof.json'));
const server=spawn(process.execPath,['tests/browser/server.mjs'],{cwd:process.cwd(),env:{...process.env,PANDOLAB_TEST_PORT:'4292'},stdio:'ignore',windowsHide:true});
for(let i=0;i<40;i++){try{const r=await fetch('http://127.0.0.1:4292/');if(r.ok)break;}catch{}await new Promise(resolve=>setTimeout(resolve,250));}
const browser=await chromium.launch({channel:'msedge',headless:true,args:['--use-angle=d3d11']});
try{
 const page=await browser.newPage({viewport:{width:1440,height:900}}),errors=[];
 page.on('pageerror',error=>errors.push(error.message));
 await page.goto('http://127.0.0.1:4292/?debug=1&demTerrain=raster');
 await expect(page.locator('#viewerStatus')).toHaveAttribute('data-ready','true',{timeout:90000});
 console.log('Web viewer ready; opening existing app-exported GPKG from disk.');
 await page.locator('#projectFileInput').setInputFiles(packagePath);
 await expect.poll(()=>page.evaluate(()=>window.__PANDOLAB_VIEWER__.documentSnapshot().territorialEntities.some(e=>e.properties.sourceEntityId==='state:deutsche-demokratische-republik')),{timeout:120000}).toBe(true);
 await expect(page.locator('#viewerStatus')).toHaveAttribute('data-ready','true',{timeout:120000});
 const opened=await page.evaluate(id=>{const document=window.__PANDOLAB_VIEWER__.documentSnapshot();
  const entity=document.territorialEntities.find(e=>e.properties.sourceEntityId===id);
  const binding=document.timelineRecords.geometryBindings.find(b=>b.entityId===entity.id);
  return {objectId:entity.id,geometry:document.geometries.find(g=>g.id===binding.geometryRef.id&&g.version===binding.geometryRef.version).geojson,
   audits:document.sourceInfo.imports.filter(row=>row.batchPrecisionAudit).map(row=>row.batchPrecisionAudit)};
 },source.entityId);
 assert.deepEqual(opened.geometry,sourceGeometry);assert.equal(opened.audits.length,1);assert.equal(opened.audits[0].discards.length,4);
 assert.equal(app.objectId,opened.objectId);assert.equal(app.before.history.checkpoint,app.undone.history.checkpoint);assert.equal(app.after.history.checkpoint,app.redone.history.checkpoint);
 await page.evaluate(()=>{const host=window.__PANDOLAB_MAP_HOST__;host.setViewState({projection:'globe',view:{...host.getViewState(),globeRotation:[-12.5,-52,0],globeZoom:14}});host.requestRepaint('ddr-source-review');});
 await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
 await page.screenshot({path:path.join(out,'web-viewer-file.png')});
 assert.deepEqual(errors,[]);
 const proof={appErrors:{pageErrors:[],unexpectedConsoleErrors:[]},sourceId:source.entityId,geometryVersion:source.geometryVersions[0].versionId,objectId:opened.objectId,
  appImport:true,undoRedo:true,webFileGeometryEqual:true,precisionAudits:opened.audits,webFileBytes:bytes.length,
  packageSha256:createHash('sha256').update(bytes).digest('hex'),webErrors:errors,
  appProof:'app-import-undo-redo-proof.json',combinedPlaywrightCase:'App import/Undo/Redo and source/audit assertions passed; combined case stopped at 8-second post-open viewer readiness assertion. Increased that assertion to 90 seconds; this Web-only continuation uses the exact exported file and a 120-second readiness wait.'};
 fs.writeFileSync(path.join(out,'web-app-proof.json'),JSON.stringify(proof,null,2)+'\n');
 console.log(JSON.stringify({...proof,precisionAudits:proof.precisionAudits.map(a=>({sourceEntityIds:a.sourceEntityIds,discardCount:a.discards.length,totalAreaM2:a.discards.reduce((n,d)=>n+d.areaM2,0)}))}));
}finally{await browser.close();server.kill();}
