import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {libraryReportRoot} from '../../../tools/library-data.mjs';
const out=path.join(libraryReportRoot(),'geography/east-germany-vg25-followup-2026-10-22');
// Reuse the existing coordinate-comparison drawing; no simulated product image.
let script=fs.readFileSync('.superpowers/sdd/ddr-boundaries/photos.mjs','utf8');
script=script.replaceAll('east-germany-boundaries-2026-10-22','east-germany-vg25-followup-2026-10-22');
const start=script.indexOf(" sheet('comparison-overview'");
const end=script.indexOf("const file=",start);
script=script.slice(0,start)+
 ` sheet('comparison-bavaria','추가 VG25 — 바이에른 접경',10.95,50.4,2560*64/360,'왼쪽: 직전 LSIB·샤알제 수정판 / 가운데: 이번 추가판 / 오른쪽: 중첩. 바이에른 중앙부를 같은 중심·배율로 비교.')+\n`+
 ` sheet('comparison-eichsfeld','추가 VG25 — 북부 아이히스펠트',10.16,51.55,1800,'변화 확인용 확대도. 남쪽 벤데바흐·베라 구간까지 동일성을 확대 주장하지 않음.')+\n`+
 ` sheet('comparison-ecker','추가 VG25 — 에커강과 댐',10.61,51.84,2200,'변화 확인용 확대도. 국립공원·측량기관 문헌으로 확인한 에커 구간에 제한.')+\n`+
 ` sheet('comparison-geismar','추가 VG25 — 가이스마르·슈팔',9.925,50.66,3400,'변화 확인용 확대도. 공식 토지정리도에서 확인한 구간만 적용; 북쪽 포인트 알파는 포함하지 않음.');\n`+
 script.slice(end);
script=script.replaceAll('ddr-boundaries/comparison.html','ddr-vg25-followup/comparison.html');
script=script.replace("await page.goto('http://127.0.0.1:4287/'+file)","await page.goto(pathToFileURL(path.resolve(file)).href)");
script=script.replace("['comparison-overview','comparison-poland','comparison-czech','comparison-schaalsee']","['comparison-bavaria','comparison-eichsfeld','comparison-ecker','comparison-geismar']");
// Generated module stays within this task workspace, with existing import depth.
fs.writeFileSync('.superpowers/sdd/ddr-vg25-followup/draw.mjs',"import {pathToFileURL} from 'node:url';\n"+script);
await import('./draw.mjs');
