# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: historical-library.spec.mjs >> East Germany static import preserves identity, archive, history and original source
- Location: tests\browser\historical-library.spec.mjs:93:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 7

- Array []
+ Array [
+   "[PL-MESH-PREPARE] Error: Invalid prepared polygon mesh: boundary edge
+     at createWorkerRpcError (http://127.0.0.1:4291/assets/js/modules/worker-rpc.js?v=0.36.0-build-cca8b8e14948:34:17)
+     at rpcErrorFromMessage (http://127.0.0.1:4291/assets/js/modules/worker-rpc.js?v=0.36.0-build-cca8b8e14948:125:12)
+     at handleMessage (http://127.0.0.1:4291/assets/js/modules/worker-rpc.js?v=0.36.0-build-cca8b8e14948:188:20)
+     at currentWorker.onmessage (http://127.0.0.1:4291/assets/js/modules/worker-rpc.js?v=0.36.0-build-cca8b8e14948:227:7)",
+ ]
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - banner [ref=e3]:
    - navigation "편집 기록" [ref=e4]:
      - button "프로젝트 변경 실행 취소" [ref=e5] [cursor=pointer]
      - button "프로젝트 변경 다시 실행" [disabled] [ref=e8]
    - navigation "문서 및 도움말" [ref=e11]:
      - button "파일 메뉴 열기" [ref=e13] [cursor=pointer]: 파일
      - button "보기" [ref=e14] [cursor=pointer]
      - button "설정" [ref=e15] [cursor=pointer]
      - button "도움말" [ref=e16] [cursor=pointer]
  - main [ref=e18]:
    - generic "지도 편집 영역" [ref=e19]:
      - img [ref=e20]:
        - generic [ref=e23]:
          - generic [ref=e24] [cursor=pointer]
          - generic [ref=e25] [cursor=pointer]
          - generic [ref=e26] [cursor=pointer]
          - generic [ref=e27] [cursor=pointer]
          - generic [ref=e28] [cursor=pointer]
          - generic [ref=e29] [cursor=pointer]
          - generic [ref=e30] [cursor=pointer]
          - generic [ref=e31] [cursor=pointer]
          - generic [ref=e32] [cursor=pointer]
          - generic [ref=e33] [cursor=pointer]
          - generic [ref=e34] [cursor=pointer]
          - generic [ref=e35] [cursor=pointer]
          - generic [ref=e36] [cursor=pointer]
          - generic [ref=e37] [cursor=pointer]
          - generic [ref=e38] [cursor=pointer]
          - generic [ref=e39] [cursor=pointer]
          - generic [ref=e40] [cursor=pointer]
          - generic [ref=e41] [cursor=pointer]
          - generic [ref=e42] [cursor=pointer]
          - generic [ref=e43] [cursor=pointer]
          - generic [ref=e44] [cursor=pointer]
          - generic [ref=e45] [cursor=pointer]
          - generic [ref=e46] [cursor=pointer]
          - generic [ref=e47] [cursor=pointer]
          - generic [ref=e48] [cursor=pointer]
          - generic [ref=e49] [cursor=pointer]
          - generic [ref=e50] [cursor=pointer]
          - generic [ref=e51] [cursor=pointer]
          - generic [ref=e52] [cursor=pointer]
          - generic [ref=e53] [cursor=pointer]
          - generic [ref=e54] [cursor=pointer]
          - generic [ref=e55] [cursor=pointer]
          - generic [ref=e56] [cursor=pointer]
          - generic [ref=e57] [cursor=pointer]
          - generic [ref=e58] [cursor=pointer]
          - generic [ref=e59] [cursor=pointer]
          - generic [ref=e60] [cursor=pointer]
          - generic [ref=e61] [cursor=pointer]
          - generic [ref=e62] [cursor=pointer]
          - generic [ref=e63] [cursor=pointer]
          - generic [ref=e64] [cursor=pointer]
          - generic [ref=e65] [cursor=pointer]
          - generic [ref=e66] [cursor=pointer]
          - generic [ref=e67] [cursor=pointer]
      - img:
        - generic:
          - generic:
            - generic [ref=e68]: 아프가니스탄
            - generic [ref=e70]: 앙골라
            - generic [ref=e72]: 아르헨티나
            - generic [ref=e74]: 남극
            - generic [ref=e76]: 오스트레일리아
            - generic [ref=e78]: 베냉
            - generic [ref=e80]: 불가리아
            - generic [ref=e82]: 바하마
            - generic [ref=e84]: 벨라루스
            - generic [ref=e86]: 볼리비아
            - generic [ref=e88]: 브라질
            - generic [ref=e90]: 보츠와나
            - generic [ref=e92]: 중앙아프리카 공화국
            - generic [ref=e94]: 캐나다
            - generic [ref=e96]: 칠레
            - generic [ref=e98]: 중화인민공화국
            - generic [ref=e100]: 콩고 민주 공화국
            - generic [ref=e102]: 쿡제도
            - generic [ref=e104]: 콜롬비아
            - generic [ref=e106]: 알제리
            - generic [ref=e108]: 이집트
            - generic [ref=e110]: 에리트레아
            - generic [ref=e112]: 에스파냐
            - generic [ref=e114]: 핀란드
            - generic [ref=e116]: 미크로네시아 연방
            - generic [ref=e118]: 조지아
            - generic [ref=e120]: 기니
            - generic [ref=e122]: 가이아나
            - generic [ref=e124]: 온두라스
            - generic [ref=e126]: 인도네시아
            - generic [ref=e128]: 인도
            - generic [ref=e130]: 이라크
            - generic [ref=e132]: 아이슬란드
            - generic [ref=e134]: 일본
            - generic [ref=e136]: 카자흐스탄
            - generic [ref=e138]: 키르기스스탄
            - generic [ref=e140]: 캄보디아
            - generic [ref=e142]: 대한민국
            - generic [ref=e144]: 라오스
            - generic [ref=e146]: 마다가스카르
            - generic [ref=e148]: 멕시코
            - generic [ref=e150]: 말리
            - generic [ref=e152]: 몽골
            - generic [ref=e154]: 니제르
            - generic [ref=e156]: 네팔
            - generic [ref=e158]: 뉴질랜드
            - generic [ref=e160]: 오만
            - generic [ref=e162]: 필리핀
            - generic [ref=e164]: 파푸아뉴기니
            - generic [ref=e166]: 러시아
            - generic [ref=e168]: 서사하라
            - generic [ref=e170]: 소말릴란드
            - generic [ref=e172]: 세이셸
            - generic [ref=e174]: 미국
            - generic [ref=e176]: 남아프리카 공화국
            - generic [ref=e178]: 프랑스령 남방 및 남극
            - generic [ref=e180]: 그린란드
            - generic [ref=e182]: 사우스조지아사우스샌드위치제도
            - generic [ref=e184]: 세인트헬레나
            - generic [ref=e186]: 미국령 군소제도
            - generic [ref=e188]: 체코
            - generic [ref=e190]: 덴마크
            - generic [ref=e192]: 프랑스
    - generic "지도 도구 및 상태":
      - generic "지도 명령" [ref=e194]:
        - button "추가" [ref=e195] [cursor=pointer]
        - button "이미지 추가" [ref=e198] [cursor=pointer]
        - button "검색" [ref=e202] [cursor=pointer]
        - button "전체 지도 보기" [ref=e205] [cursor=pointer]
      - region "지도 렌더러 진단" [ref=e208]:
        - generic [ref=e209]: "renderer: webgl2 map host: legacy / flat WebGL contexts: 1 mesh quality: canonical render revision: 154 view revision: 2 full / view renders: 4 / 149 last render: 217.7 ms label layouts: 138 selection paths / chars: 0 / 0 GPU picks: 0 / 0.0 ms state revision: 3 pending country patches: 2 affected country ids: b47b299e-516d-47fb-a98a-d529ac9ec1cd, DEU worker busy: no edit queue / running: 0 / 0 coalesced / stale: 0 / 0 edit worker p95: 1545.7 ms preview update: 0.00 ms / 0 segments edit commit: 0.0 ms / — patch queue / stale: 0 / 0 patch GPU bytes: 0 frame p95 / p99: 54.8 / 99.2 ms terrain / hydro: idle / idle audit: idle"
        - button "전체 지도 검사" [ref=e210] [cursor=pointer]
      - generic "지도 상태":
        - generic:
          - generic "저장되지 않은 변경 사항이 있습니다.": 미저장
          - generic "보기 정보": 평면지도
          - status: 현재 화면 준비 완료 · 저배율 표시
```

# Test source

```ts
  64  |     const core = window.__libraryCoreOwner.state();
  65  |     return {
  66  |       entities: await hash(state.territorialEntities),
  67  |       records: await hash(state.timelineRecords),
  68  |       archive: await hash(state.geometries.snapshot()),
  69  |       history: {checkpoint:core.checkpoint,canUndo:core.canUndo,canRedo:core.canRedo,
  70  |         undoCommandId:core.undoCommandId,redoCommandId:core.redoCommandId},
  71  |       source: await hash(source), sourceInfo: await hash(state.sourceInfo),
  72  |       savedProject: await hash(saved), saveState: window.__librarySaveState.checkpoint(),
  73  |       stateRevision: core.stateRevision, epoch: core.epoch,
  74  |       selection: window.__librarySelection.snapshot().selection,
  75  |       session: { projection: state.projection, view: state.view, tool: state.tool,
  76  |         countryVisualPhase: state.countryVisualPhase, pendingCountryRenderIds: [...state.pendingCountryRenderIds] },
  77  |       publication: { projectGeneration: rendering.projectGeneration,
  78  |         territorialBoundaryRevision: rendering.territorialBoundaryRevision,
  79  |         activeMeshQuality: rendering.gpu.activeMeshQuality },
  80  |       germanyName: window.PANDOLAB_TERRITORIAL.get('DEU').properties.name,
  81  |     };
  82  |   }, sourceId);
  83  | }
  84  | 
  85  | export async function openLibrary(page, {renderer='webgl2', nativeActionTestInfo=null}={}) {
  86  |   page.setDefaultTimeout(10_000);
  87  |   await observeOwners(page);
  88  |   const pageErrors = [], unexpectedConsoleErrors = [];
  89  |   page.on('pageerror', error => pageErrors.push(error.message));
  90  |   page.on('console', message => {
  91  |     if (message.type() === 'error' && !message.text().startsWith('[PL-LIB-002]')) unexpectedConsoleErrors.push(message.text());
  92  |   });
  93  |   await page.setViewportSize({ width: 1440, height: 900 });
  94  |   await gotoEditor(page, `/?debug=1&demTerrain=raster${renderer==='canvas'?'&renderer=canvas':''}`);
  95  |   await expect(page.locator('#bootstrapLoading')).toHaveAttribute('hidden', '', { timeout: 45_000 });
  96  |   await expect(page.locator('#app')).toHaveAttribute('data-readiness', 'enhanced', { timeout: 90_000 });
  97  |   // Preserve a real nonempty Undo and Redo chain through a rejected operation.
  98  |   expect(await page.evaluate(() => window.PANDOLAB_TERRITORIAL.setName('DEU', '보존 이름 A'))).toMatchObject({ changed: true });
  99  |   expect(await page.evaluate(() => window.PANDOLAB_TERRITORIAL.setName('DEU', '보존 이름 B'))).toMatchObject({ changed: true });
  100 |   if (nativeActionTestInfo) {
  101 |     await withNativeActionDiagnostics(page, nativeActionTestInfo, { label: 'library-setup-undo', selector: '#undoBtn' }, async () => {
  102 |       await page.locator('#undoBtn').click();
  103 |     });
  104 |   } else {
  105 |     await page.locator('#undoBtn').click();
  106 |   }
  107 |   expect(await page.evaluate(() => window.PANDOLAB_TERRITORIAL.select('DEU'))).toBe(true);
  108 |   await expect.poll(() => page.evaluate(() => window.__librarySaveState.snapshot().autosave), { timeout: 30_000 }).toBe('saved');
  109 |   await page.locator('#createMenuBtn').click();
  110 |   await page.locator('#addFromLibraryBtn').click();
  111 |   await expect(page.locator('#territorialLibraryModal')).toBeVisible();
  112 |   return { pageErrors, unexpectedConsoleErrors };
  113 | }
  114 | 
  115 | export async function importFiniteSource(page, testInfo, id, errors, { referenceDate }) {
  116 |   // The caller supplies its own expected full cursor, including blank representatives.
  117 |   // Never infer this expectation from the imported descriptor or UI normalizer.
  118 |   expect(referenceDate).toMatch(/^-?\d{4,}-\d{2}-\d{2}$/);
  119 |   const before=await stateProof(page,id);
  120 |   const source=await page.evaluate(id=>window.PANDOLAB_TERRITORIAL_LIBRARY.get(id),id);
  121 |   expect(source.lifetime.validFrom || source.lifetime.validTo).toBeTruthy();
  122 |   const inputDate=await page.locator('#territorialLibraryReferenceDateInput').inputValue();
  123 |   const editMonth=await page.evaluate(() => window.__testEditorTimeline.month());
  124 |   const timelineEditsEnabled=await page.evaluate(()=>window.__libraryCoreOwner.state().timelineEditsEnabled);
  125 |   const selected=await page.evaluate(async({id,referenceDate})=>{
  126 |     const {selectGeometryVersion}=await import('/assets/js/modules/territorial-library.js');
  127 |     return selectGeometryVersion(await window.PANDOLAB_TERRITORIAL_LIBRARY.get(id),referenceDate);
  128 |   },{id,referenceDate});
  129 |   expect(selected).toBeTruthy();
  130 |   await expect(page.locator('#territorialLibraryPreview [data-geometry-version-id]')).toHaveAttribute('data-geometry-version-id',selected.versionId);
  131 |   await page.locator('#territorialLibraryAddBtn').click();
  132 |   await expect.poll(async()=> {
  133 |     const failures=await page.evaluate(()=>window.__libraryErrors);
  134 |     if(failures.length)throw new Error(JSON.stringify(failures));
  135 |     return (await page.locator('[data-library-impact]').count()) || (await page.locator('#territorialLibraryModal.hidden').count());
  136 |   },{timeout:60_000}).toBeGreaterThan(0);
  137 |   if(await page.locator('[data-library-impact]').count())await page.locator('#territorialLibraryAddBtn').click();
  138 |   await expect(page.locator('#territorialLibraryModal')).toBeHidden({timeout:60_000});
  139 |   const added=await page.evaluate(id=>window.PANDOLAB_TERRITORIAL.list().filter(e=>e.properties.sourceEntityId===id),id);
  140 |   expect(added).toHaveLength(1);expect(added[0].id).not.toBe(id);
  141 |   expect(added[0].geometry).toEqual(selected.geometry);
  142 |   expect(added[0].properties).toMatchObject({validFrom:timelineEditsEnabled?editMonth:null,validTo:null,sourceGeometryVersion:selected.versionId,
  143 |     metadata:{sourceLifetime:source.lifetime,sourceGeometryValidity:{validFrom:selected.validFrom,validTo:selected.validTo},
  144 |       sourceReferenceDate:referenceDate,sourceInfo:source.sourceInfo,geometryCertainty:selected.certainty,geometryDatePrecision:selected.datePrecision}});
  145 |   await expect(page.locator('#territorialLibraryReferenceDateInput')).toHaveValue(inputDate);
  146 |   const after=await stateProof(page,id);
  147 |   expect(after.history.checkpoint).not.toBe(before.history.checkpoint);
  148 |   expect(after.history.canUndo).toBe(true);expect(after.history.canRedo).toBe(false);
  149 |   expect(after.source).toBe(before.source);
  150 |   await page.locator('#undoBtn').click({timeout:30_000,noWaitAfter:true});
  151 |   await expect.poll(()=>page.evaluate(id=>window.PANDOLAB_TERRITORIAL.list().some(e=>e.properties.sourceEntityId===id),id),{timeout:30_000}).toBe(false);
  152 |   const undone=await stateProof(page,id);
  153 |   expect(undone.history.checkpoint).toBe(before.history.checkpoint);
  154 |   expect(undone.history.canRedo).toBe(true);
  155 |   for(const key of ['entities','records','archive','source','sourceInfo'])expect(undone[key],key).toBe(before[key]);
  156 |   await page.locator('#redoBtn').click({timeout:30_000,noWaitAfter:true});
  157 |   await expect.poll(()=>page.evaluate(id=>window.PANDOLAB_TERRITORIAL.list().filter(e=>e.properties.sourceEntityId===id).map(e=>e.id),id),{timeout:30_000}).toEqual([added[0].id]);
  158 |   const redone=await stateProof(page,id);for(const key of ['entities','records','archive','source','sourceInfo'])expect(redone[key],key).toBe(after[key]);
  159 |   expect(redone.history.checkpoint).toBe(after.history.checkpoint);
  160 |   expect(redone.history.undoCommandId).toBe(after.history.undoCommandId);
  161 |   const proofPath=testInfo.outputPath('static-import-provenance.json');
  162 |   await writeFile(proofPath,JSON.stringify({id,inputDate,referenceDate,versionId:selected.versionId,objectId:added[0].id,before,after,undone,redone}));
  163 |   await testInfo.attach('static-import-provenance',{path:proofPath,contentType:'application/json'});
> 164 |   expect(errors.pageErrors).toEqual([]);expect(errors.unexpectedConsoleErrors).toEqual([]);
      |                                                                                ^ Error: expect(received).toEqual(expected) // deep equality
  165 | }
  166 | 
```