import json, hashlib, sys
from pathlib import Path
from shapely.geometry import shape, box
from shapely.ops import unary_union, transform
from pyproj import Transformer, Geod
sys.path.insert(0,str(Path.cwd()))
from tools.report_paths import report_path
out=report_path('reports/geography/east-germany-vg25-followup-2026-10-22')
before=json.loads((out/'before-source.json').read_text(encoding='utf8'))
after=json.loads(Path('assets/data/territorial-entities/source/countries/state-deutsche-demokratische-republik.json').read_text(encoding='utf8'))
recipe=json.loads(Path('tools/historical-library/east-germany-1989.recipe.json').read_text(encoding='utf8'))
a,b=[shape(row['geometryVersions'][0]['geometry']) for row in (before,after)]
new_sections=[s for s in recipe['operations'][-1]['sections'] if s['id']!='vg25-schaalsee-lake']
windows=unary_union([box(*s['bounds']) for s in new_sections])
delta=a.symmetric_difference(b)
assert b.is_valid and len(a.geoms)==len(b.geoms)==6
assert before['lifetime']==after['lifetime'] and before['metadata']==after['metadata']
assert delta.difference(windows.buffer(3e-12)).difference(a.boundary.buffer(3e-12)).is_empty
assert a.boundary.difference(windows).hausdorff_distance(b.boundary.difference(windows))<3e-11
foreign=json.loads(report_path('reports/geography/east-germany-boundaries-2026-10-22/preserved-foreign-sources.json').read_text())
actual={code:hashlib.sha256(Path(f'assets/data/territorial-entities/source/countries/state-{code}.json').read_bytes()).hexdigest() for code in foreign}
assert actual==foreign
for region in [(9,53.44,16,56),(10.25,52.7,12,53.44),(12,50.05,15.1,53.3)]:
    assert delta.intersection(box(*region)).difference(a.boundary.buffer(3e-12)).is_empty
def count(g):return sum(len(r.coords) for p in g.geoms for r in [p.exterior,*p.interiors])
geod=Geod(ellps='WGS84')
result={'referenceDate':recipe['referenceDate'],'beforeCoordinates':count(a),'afterCoordinates':count(b),
 'beforePolygons':len(a.geoms),'afterPolygons':len(b.geoms),'valid':b.is_valid,
 'beforeAreaKm2':abs(geod.geometry_area_perimeter(a)[0])/1e6,'afterAreaKm2':abs(geod.geometry_area_perimeter(b)[0])/1e6,
 'lifetimeAndMetadataUnchanged':True,'foreignSourceHashesUnchanged':actual,
 'changesConfinedToNewWindowsWithinDegrees':3e-12,'internationalCoastBerlinNeuhausAndSchaalseePreserved':True,
 'newSections':new_sections,'historicalAccuracy':'documentary continuity plus visual review; no independent 1989 vector, no 0.5px pass claim',
 'focusedTests':'tests.test_v0300_east_germany_library: 7 passed'}
(out/'geometry-proof.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(out/'after-source.json').write_text(json.dumps(after,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in result.items() if k not in ['newSections','foreignSourceHashesUnchanged']},ensure_ascii=False))
