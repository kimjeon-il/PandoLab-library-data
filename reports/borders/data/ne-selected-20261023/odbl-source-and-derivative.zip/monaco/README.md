# Selected Monaco NE-coast 100 m derivative recovery

Reconstructed from preserved pre-LSIB Natural Earth baseline and original Department of State LSIB 11.4 border; no repository modifications, publication, archive or upload performed here.

## Deliverables
- `selected-monaco.geojson`, `selected-france.geojson`: paired geometry-only GeoJSON, intended for parent's metadata-preserving integration.
- `precise-monaco.geojson`, `precise-france.geojson`: recovered precise master pair, separately preserved.
- `precise-land-line.geojson`, `selected-land-line.geojson`, `fixed-extension.geojson`: explicit derivation components.
- `recover.py`: deterministic, rerunnable recovery; Python dependencies under `deps/`.
- `source/`: original baseline country containers, original LSIB and preserved official XML/verification. `source-hashes.json` hashes exact reconstruction inputs.
- `metrics.json`, `verification-output.txt`: asserted geometric validation and recorded metric reproduction.

## Method and reproduction
Run `python recovery/monaco/recover.py` from workspace root. Source inputs are self-contained in this folder. Dependencies used: Shapely 2.2.0 and pyproj 3.8.0. The preserved dependency folder is environment-specific, not a portable application or distribution.

Union baseline France and Monaco to retain the complete NE coastline; trim the LSIB part seaward of that union (453.3925 m), and extend its final segment to NE coast (367.7288 m). Split that unchanged coast polygon using the extended border. Simplify only the 244-point clipped LSIB land line in EPSG:32632 at 100 m, keeping the extension separate and fixed. Douglas–Peucker returns 10 original source points. Preserve original geographic coordinates rather than projection round-trip approximations. Splice this single shared line into both countries.

All recorded selection metrics reproduced: precise/simplified rings 249/15; geodesic areas 1.9766589317/1.9968463502 km²; max projected deviation 84.205543 m. Simplifying extension together with the land border produces a different area and is explicitly not used.

Paired union is exactly unchanged between precise and simplified outputs; overlap and shared-edge omission zero. All original exterior coastline vertices are retained, two junctions added. Relative to baseline union, floating intersection residual is 1.776e-15 degrees Hausdorff and 1.55e-17 square degrees symmetric-difference area (not a meaningful coast edit).

Prior selected candidate files are unavailable; no byte-for-byte identity to those files is claimed. Original sources, inferred method, and every recorded rounded metric match. The validation counts 4,607 distinct exterior coastline vertices. The historical 4,618 coastline-coordinate count used an unavailable counting convention, so that count is not claimed as independently reproduced; complete coordinate-set retention is independently asserted.

## Sources and limitations
NE baseline: Pando revision `4c7f30453fc5de61efd1ab0fb03d7fdaa92fe3a7`; Natural Earth 5.1.1. Official LSIB fid194 ID `1e220d96-aa9e-43f8-834a-d580059f60b7`, original WP 11.4 beta archive SHA256 `55fab422ef09e35eb48d68141b9ece0ace86d4276dfe332a04dfd401c0bfc80c`; https://data.geodata.state.gov/WorldPolygons.zip and https://data.geodata.state.gov/waf/iso/worldpolygons.xml . U.S. Government work notice and third-party-rights disclaimer are preserved in XML. NE component is public domain.

The endpoint extension is a generalized display connection, not a legally established straight-line border. No historical effective date or historical accuracy is established. The 100 m tolerance is the user-selected tiny-state display exception for NE 1:10M, not a universally mandated scale conversion. Existing historical geometry versions, entity metadata and dates must be preserved by integration. Policy read before work: repository work/gis `docs/historical-border-reconstruction-policy.md`.
