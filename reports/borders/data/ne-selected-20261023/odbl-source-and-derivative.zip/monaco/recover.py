"""Recover selected Monaco candidate from preserved baseline and LSIB originals.
Run: python recovery/monaco/recover.py. Dependencies in ./deps.
The 100 m simplification excludes and preserves the NE endpoint extension.
"""
import sys,pathlib,json,hashlib,copy,warnings
P=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(P/'deps'))
warnings.filterwarnings('ignore',category=DeprecationWarning)
from shapely.geometry import shape,mapping,LineString,Polygon,MultiPolygon
from shapely.ops import linemerge,transform,split
from pyproj import Transformer,Geod
S=P.parent/'ne-country-data'; geod=Geod(ellps='WGS84')
base={e['entityId']:e for f in [P/'source/france.json',P/'source/mco.json'] for e in json.load(open(f))['entities']}
fg,mg=[shape(base[x]['geometryVersions'][0]['geometry']) for x in ['state:FRA','state:MCO']]
u=fg.union(mg); mainland=next(g for g in u.geoms if g.distance(mg)==0)
l=linemerge(shape(json.load(open(P/'source/FRA_MCO_LSIB11_4_original.geojson'))['features'][0]['geometry']))
c=list(l.coords); a,b=c[-2:]; t=(b[0]+(b[0]-a[0])*100,b[1]+(b[1]-a[1])*100)
precise_with_extension=LineString(c+[t]).intersection(mainland)
cc=list(precise_with_extension.coords); a,b=cc[:2]; ss=(a[0]+(a[0]-b[0])*2,a[1]+(a[1]-b[1])*2)
pieces=list(split(mainland,LineString([ss]+c+[t])).geoms); assert len(pieces)==2
m=min(pieces,key=lambda x:x.area); assert len(m.exterior.coords)==249
# The history's 244->10 points counts the land line without the separate extension.
land=LineString(cc[:-1]); assert len(land.coords)==244
f=Transformer.from_crs('EPSG:4326','EPSG:32632',always_xy=True).transform
inv=Transformer.from_crs('EPSG:32632','EPSG:4326',always_xy=True).transform
projected=transform(f,land).simplify(100)
# Douglas-Peucker selects input vertices. Restore exact original geographic coordinates,
# not projection round-trip approximations, so unchanged source points stay identical.
sc=[min(cc,key=lambda x:(x[0]-p[0])**2+(x[1]-p[1])**2) for p in transform(inv,projected).coords]
assert len(sc)==10
simplified=LineString(sc); full_sc=sc+[cc[-1]]
sset=set(full_sc); cset=set(cc)
sm=Polygon([x for x in m.exterior.coords if x in sset or x not in cset]); assert len(sm.exterior.coords)==15
# Construct paired France from the same split and identical selected shared vertices.
frmain=max(pieces,key=lambda x:x.area)
sfrmain=Polygon([x for x in frmain.exterior.coords if x in sset or x not in cset],[list(r.coords) for r in frmain.interiors])
others=[g for g in u.geoms if g!=mainland]
pfra=MultiPolygon([frmain]+others); sfra=MultiPolygon([sfrmain]+others)
precise_union=pfra.union(m); simple_union=sfra.union(sm)
assert sfra.is_valid and sm.is_valid and pfra.is_valid and m.is_valid
assert sfra.intersection(sm).area==0
assert simple_union.equals(precise_union)
assert sfra.boundary.intersection(sm.boundary).equals(LineString(full_sc))
assert pfra.boundary.intersection(m.boundary).equals(precise_with_extension)
assert precise_union.symmetric_difference(u).area < 1e-12
original_coast_vertices={tuple(x) for p in u.geoms for x in p.exterior.coords}
new_coast_vertices={tuple(x) for p in simple_union.geoms for x in p.exterior.coords}
assert original_coast_vertices<=new_coast_vertices
metrics={'status':'deterministically recovered; all recorded rounded selection metrics match','baseline_union_area_difference_degrees2':precise_union.symmetric_difference(u).area,'baseline_coast_hausdorff_degrees':precise_union.boundary.hausdorff_distance(u.boundary),'precise_to_simplified_union_area_difference_degrees2':simple_union.symmetric_difference(precise_union).area,'precise_to_simplified_union_hausdorff_degrees':simple_union.hausdorff_distance(precise_union),'overlap_area_degrees2':sfra.intersection(sm).area,'shared_edge_missing_degrees':LineString(full_sc).difference(sfra.boundary.intersection(sm.boundary)).length,'precise_land_points':len(land.coords),'simplified_land_points':len(sc),'precise_ring_points':len(m.exterior.coords),'simplified_ring_points':len(sm.exterior.coords),'precise_area_km2':abs(geod.geometry_area_perimeter(m)[0])/1e6,'simplified_area_km2':abs(geod.geometry_area_perimeter(sm)[0])/1e6,'SW_trim_m':geod.geometry_length(l.difference(mainland)),'NE_extension_m':geod.geometry_length(LineString(cc[-2:])),'last_segment_m':geod.geometry_length(LineString(c[-2:])),'maximum_deviation_UTM32_m':transform(f,land).hausdorff_distance(transform(f,simplified)),'tolerance_m':100,'all_original_exterior_coast_vertices_retained':True,'original_unique_exterior_vertices':len(original_coast_vertices),'new_unique_exterior_vertices':len(new_coast_vertices),'selected_original_clipped_line_vertex_indices':[cc.index(x) for x in sc],'projection':'EPSG:32632','areas':'WGS84 geodesic','coordinate_identity_caveat':'Prior candidate file is unavailable; reconstruction matches source, method and all recorded rounded metrics, not a prior file hash.'}
expected={'precise_area_km2':1.97666,'simplified_area_km2':1.99685,'SW_trim_m':453.39,'NE_extension_m':367.73,'maximum_deviation_UTM32_m':84.21}
for k,v in expected.items():assert round(metrics[k],5 if 'area_km2' in k else 2)==v,(k,metrics[k],v)
def write(name,obj):
 (P/name).write_text(json.dumps(obj,ensure_ascii=False,separators=(',',':'))+'\n')
for name,g in [('precise-monaco.geojson',m),('precise-france.geojson',pfra),('selected-monaco.geojson',sm),('selected-france.geojson',sfra),('precise-land-line.geojson',land),('selected-land-line.geojson',simplified),('fixed-extension.geojson',LineString(cc[-2:]))]:write(name,mapping(g))
write('metrics.json',metrics)
write('source-hashes.json',{str(f.relative_to(P)):hashlib.sha256(f.read_bytes()).hexdigest() for f in [P/'source/france.json',P/'source/mco.json',P/'source/FRA_MCO_LSIB11_4_original.geojson']})
print(json.dumps(metrics,indent=2))
