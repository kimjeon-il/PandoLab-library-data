import sys;sys.path.insert(0,str(__import__('pathlib').Path(__file__).resolve().parents[1]/'deps'))
import json,xml.etree.ElementTree as E
from shapely.geometry import Polygon,LineString,Point,mapping
from shapely.ops import unary_union,transform,substring
from pyproj import Transformer,Geod
from pathlib import Path
D=Path(__file__).resolve().parent/'source';forward=Transformer.from_crs(4326,32641,always_xy=True).transform;back=Transformer.from_crs(32641,4326,always_xy=True).transform;geod=Geod(ellps='WGS84')
ns={};ws={};rs={}
for f in ['river-west','river-east']:
 r=E.parse(D/(f+'.osm')).getroot();ns.update({x.get('id'):(float(x.get('lon')),float(x.get('lat')))for x in r.findall('node')});ws.update({x.get('id'):x for x in r.findall('way')});rs.update({x.get('id'):x for x in r.findall('relation')})
polys=[]
for id,a in rs.items():
 t={x.get('k'):x.get('v')for x in a.findall('tag')}
 if t.get('water')!='river':continue
 out=[]
 for m in a.findall('member'):
  if m.get('role')!='outer':continue
  out.append([ns[x.get('ref')]for x in ws[m.get('ref')].findall('nd')])
 if len(out)==1: polys.append(Polygon(out[0]));print('water',id,len(out[0]),Polygon(out[0]).bounds)
 else:
  from shapely.ops import linemerge
  ln=linemerge([LineString(x)for x in out]);polys.append(Polygon(ln))
water=unary_union(polys);print('water type',water.geom_type)
secs=json.load(open(D/'coordinate-transcription.json'))['sections'];p=[x['coordinate']for x in secs['Участок № 1']]
paths={}
for a,b in [(17,18),(31,1)]:
 pa,pb=[Point(forward(*p[i-1]))for i in [a,b]]
 rings=[transform(forward,x.exterior)for x in (water.geoms if hasattr(water,'geoms')else [water])]
 ring=min(rings,key=lambda r:r.distance(pa)+r.distance(pb))
 rc=list(ring.coords)[:-1]; i=min(range(len(rc)),key=lambda i:rc[i][0]);j=max(range(len(rc)),key=lambda i:rc[i][0]);i,j=sorted([i,j])
 banks=[LineString(rc[i:j+1]),LineString(rc[j:]+rc[:i+1])]
 ring=max(banks,key=lambda x:sum(y for _,y in x.coords)/len(x.coords)); da,db=ring.project(pa),ring.project(pb)
 s=substring(ring,da,db);other=LineString(list(substring(ring,max(da,db),ring.length).coords)+list(substring(ring,0,min(da,db)).coords))
 print('ring',ring.length,'direct',s.length,'other',other.length)
 # bank is open; no wrapped alternative
 print('path',a,b,'length',s.length,'snaps',ring.distance(pa),ring.distance(pb),'coords',len(s.coords));paths[a]=list(transform(back,s.simplify(100)).coords)
coords=[]
for i,xy in enumerate(p,1):
 coords.append(xy)
 if i in paths:coords.extend(paths[i])
poly=Polygon(coords)
exc=[Polygon([x['coordinate'] for x in secs['Участок № '+i]])for i in ['1-1','1-2','1-3','1-4']]
dms=lambda d,m,s:d+m/60+s/3600
exc+=[Polygon([(dms(63,18,0),dms(45,39,25)),(dms(63,19,30),dms(45,39,25)),(dms(63,18,30),dms(45,38,50)),(dms(63,18,10),dms(45,38,40))]),Polygon([(dms(63,15,25),dms(45,36,30)),(dms(63,16,20),dms(45,36,30)),(dms(63,16,20),dms(45,35,50)),(dms(63,15,25),dms(45,35,50))])]
poly=poly.difference(unary_union(exc))
def stats(p):return {'valid':p.is_valid,'type':p.geom_type,'area':abs(geod.geometry_area_perimeter(p)[0])/1e6,'vertices':len(p.exterior.coords)+sum(len(r.coords)for r in p.interiors),'holes':len(p.interiors)}
print('reconstruction',stats(poly));(D.parent/'reconstructed100m.geojson').write_text(json.dumps(mapping(poly)))
print('ring sizes',len(poly.exterior.coords),[(len(r.coords),abs(geod.geometry_area_perimeter(Polygon(r))[0])/1e6) for r in poly.interiors])
print('valid reason',__import__('shapely').is_valid_reason(poly))
