from pathlib import Path
import sys,os,json,hashlib,runpy
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'deps'));os.environ['MPLCONFIGDIR']=str(HERE/'.mplconfig')
from shapely.geometry import Polygon,LineString,Point,shape,mapping
from shapely.ops import transform,unary_union
from shapely import segmentize,is_valid_reason
from shapely.geometry.polygon import orient
v=runpy.run_path(str(HERE/'reconstruct_source.py'))
p,paths,exc,source,fw,bk,geod=[v[k]for k in ['p','paths','exc','poly','forward','back','geod']]
# Whole-outline constrained simplification. Protect major official vertices and
# every southern connector/rectangle point; minor northern detours are eligible.
raw=[];anchors=[]
protected=set(range(1,32))-{6,7,11,12,13}
for i,xy in enumerate(p,1):
 if i in protected:anchors.append(len(raw))
 raw.append(xy)
 if i in paths:raw.extend(paths[i])
raw.append(raw[0]);coords=[]
for k,a in enumerate(anchors):
 b=anchors[k+1] if k+1<len(anchors) else len(raw)-1
 chain=raw[a:b+1]
 simplified=list(transform(bk,transform(fw,LineString(chain)).simplify(1000,preserve_topology=True)).coords)
 simplified[0]=tuple(chain[0]);simplified[-1]=tuple(chain[-1])
 coords.extend(simplified[:-1])
outer=Polygon(coords);assert outer.is_valid,is_valid_reason(outer)
# Simplify exclusion outlines conservatively: a vertex is removable only when
# its removal does not invade ANY original excluded area and whole-boundary
# displacement remains <= 1000 m. No convex-hull substitute or area fitting.
large=[];exclusion_changes=[]
for original in exc[:4]:
 c=list(original.exterior.coords)[:-1];changed=True
 while changed and len(c)>3:
  changed=False
  for i in range(len(c)):
   test=Polygon(c[:i]+c[i+1:])
   if not test.is_valid or not test.covers(original):continue
   diff=outer.difference(test); original_diff=outer.difference(original)
   if diff.geom_type != original_diff.geom_type or len(diff.interiors)!=len(original_diff.interiors):continue
   distance=transform(fw,segmentize(original.boundary,.005)).hausdorff_distance(transform(fw,segmentize(test.boundary,.005)))
   if distance<=1000:
    c.pop(i);changed=True;break
 out=Polygon(c);large.append(out)
 exclusion_changes.append({'source_vertices':len(original.exterior.coords),'display_vertices':len(out.exterior.coords),'original_area_covered':out.covers(original),'boundary_hausdorff_m':transform(fw,segmentize(original.boundary,.005)).hausdorff_distance(transform(fw,segmentize(out.boundary,.005))),'additional_excluded_area_km2':abs(geod.geometry_area_perimeter(orient(out,sign=1))[0])/1e6-abs(geod.geometry_area_perimeter(orient(original,sign=1))[0])/1e6})
kab=outer.difference(unary_union(large));assert kab.is_valid,is_valid_reason(kab)
def load(id):return shape(json.load(open(HERE/'source'/('state-'+id+'.json')))['geometryVersions'][0]['geometry'])
oldkab,oldkaz=load('KAB'),load('KAZ');total=oldkab.union(oldkaz);kaz=total.difference(kab)
def area(g):
 if g.is_empty:return 0.
 if hasattr(g,'geoms'):return sum(area(x)for x in g.geoms)
 return abs(geod.geometry_area_perimeter(orient(g,sign=1))[0])/1e6

def stat(g):
 gs=list(g.geoms)if hasattr(g,'geoms')else[g]
 return {'area_km2':area(g),'vertices_including_closure':sum(len(x.exterior.coords)+sum(len(r.coords)for r in x.interiors)for x in gs),'vertices_excluding_closure':sum(len(x.exterior.coords)-1+sum(len(r.coords)-1 for r in x.interiors)for x in gs),'holes':sum(len(x.interiors)for x in gs),'valid':g.is_valid}
checks={'overlap_deg2':kab.intersection(kaz).area,'gap_deg2':total.difference(kab.union(kaz)).area,'union_symmetric_difference_deg2':total.symmetric_difference(kab.union(kaz)).area,'kab_outside_original_sovereign_union_deg2':kab.difference(total).area,'shared_boundary_missing_degrees':kab.boundary.difference(kaz.boundary).length,'large_exclusion_intrusion_deg2':[kab.intersection(e).area for e in exc[:4]],'southern_points_21_to_30_retained':all(kab.boundary.distance(Point(x))<1e-12 for x in p[20:30]),'kaz_valid':kaz.is_valid,'kab_valid':kab.is_valid}
# Densification is for distance QA only, never used to change product topology.
dense=lambda g:transform(fw,segmentize(g,0.005))
checks['exterior_hausdorff_m']=dense(source.exterior).hausdorff_distance(dense(kab.exterior))
checks['protected_official_points_retained']=all(kab.boundary.distance(Point(p[i-1]))<1e-12 for i in protected)
assert checks['exterior_hausdorff_m']<=1000 and checks['protected_official_points_retained']
assert len(kab.interiors)==3
assert all(checks[k]==0 for k in ['overlap_deg2','gap_deg2','union_symmetric_difference_deg2','kab_outside_original_sovereign_union_deg2','shared_boundary_missing_degrees'])
assert all(x==0 for x in checks['large_exclusion_intrusion_deg2'])
assert checks['southern_points_21_to_30_retained'] and kaz.is_valid
metrics={'status':'NEW REMADE CANDIDATE — NOT IDENTICAL TO PREVIOUS A — AWAITING USER REVIEW','tolerance_m':1000,'old_ellipse':stat(oldkab),'reconstructed100m':stat(source),'remade1km':stat(kab),'small_exclusions_omitted_km2':sum(area(e)for e in exc[4:]),'checks':checks,'exclusion_generalization':exclusion_changes,'protected_official_points':sorted(protected),'method':'Whole-outline constrained 1000 m simplification: protect major official vertices and southern points; simplify river and eligible minor northern detours; conservatively simplify all four exclusions while covering their full original areas; WGS84 boolean subtraction; omit only small Toretam/Akai holes.'}
for name,g in [('KAB',kab),('KAZ',kaz)]:
 (HERE/(name+'.geojson')).write_text(json.dumps({'type':'Feature','properties':{'entityId':'state:'+name,'status':metrics['status']},'geometry':mapping(g)},ensure_ascii=False))
(HERE/'paired.geojson').write_text(json.dumps({'type':'FeatureCollection','features':[json.load(open(HERE/(n+'.geojson')))for n in ['KAB','KAZ']]},ensure_ascii=False))
(HERE/'metrics.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2))
print(json.dumps(metrics,ensure_ascii=False,indent=2))
# Comparison with identical extent and conspicuous new-candidate status.
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from matplotlib.path import Path as MPath
from matplotlib.patches import PathPatch
font=FontProperties(fname='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
plt.rcParams['axes.unicode_minus']=False
fig,axs=plt.subplots(1,3,figsize=(18,7),dpi=160)
def draw(ax,g,color,alpha=.4):
 g=orient(g,sign=1);verts=[];codes=[]
 for r in [g.exterior,*g.interiors]:
  c=list(r.coords);verts.extend(c);codes.extend([MPath.MOVETO]+[MPath.LINETO]*(len(c)-2)+[MPath.CLOSEPOLY])
 ax.add_patch(PathPatch(MPath(verts,codes),facecolor=color,edgecolor=color,alpha=alpha,lw=1.3))
for ax,g,title,col in zip(axs,[oldkab,source,kab],['기존 타원 · 보정 전','새로 복구한 100 m 원형','새 1 km 표시 후보 · 검토 필요'],['#9b718f','#347daf','#14816b']):
 ax.set_facecolor('#f4f7f8');draw(ax,g,col)
 for e in exc[:4]:ax.plot(*e.exterior.xy,color='#d76b2b',lw=.9)
 ax.plot(*source.exterior.xy,color='#466476',lw=.55,alpha=.45)
 st=stat(g);ax.set_title(f'{title}\n{st["area_km2"]:,.3f} km² · {st["vertices_including_closure"]} 좌표 · 구멍 {st["holes"]}개',fontproperties=font,fontsize=12,pad=12)
 ax.set_xlim(62.68,64.38);ax.set_ylim(45.39,46.44);ax.set_aspect(1/0.695);ax.grid(alpha=.15);ax.tick_params(labelsize=8)
 ax.set_xlabel('경도 (°E)',fontproperties=font);ax.set_ylabel('위도 (°N)',fontproperties=font)
fig.suptitle('바이코누르 경계 재작성 비교 — 이전 A의 정확 복원이 아닌 새 후보',fontproperties=font,fontsize=18,y=.98)
fig.text(.03,.055,'주황색: 보존한 대형 제외구역 4곳  |  남쪽 사각형·좁은 연결부 및 주요 공식 꺾임점 유지  |  작은 구멍 2곳만 표시에서 생략',fontproperties=font,fontsize=11)
fig.text(.03,.02,'조약 좌표 datum 미확인 · OSM 우안 자료(2021 편집) · 도로/철도 제외 폭 미해결 · © OpenStreetMap contributors / ODbL',fontproperties=font,fontsize=9,color='#555')
fig.subplots_adjust(top=.83,bottom=.15,wspace=.24)
fig.savefig(HERE/'comparison-ko.png',facecolor='white');plt.close(fig)
(HERE/'SHA256SUMS').write_text('\n'.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+str(f.relative_to(HERE)) for f in sorted(HERE.rglob('*'))if f.is_file() and f.name!='SHA256SUMS' and '.mplconfig' not in str(f)))
