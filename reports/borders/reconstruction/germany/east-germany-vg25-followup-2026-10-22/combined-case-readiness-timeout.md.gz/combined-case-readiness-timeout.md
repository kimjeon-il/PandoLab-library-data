# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: historical-library.spec.mjs >> East Germany static import preserves identity, archive, history and original source
- Location: tests\browser\historical-library.spec.mjs:93:1

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator:  locator('#viewerStatus')
Expected: "true"
Received: "false"
Timeout:  8000ms

Call log:
  - Expect "toHaveAttribute" with timeout 8000ms
  - waiting for locator('#viewerStatus')
    19 × locator resolved to <span role="status" id="viewerStatus" aria-live="polite" data-ready="false" class="viewer-loading">지도 불러오는 중…</span>
       - unexpected value "false"

```

```yaml
- status: 지도 불러오는 중…
```

# Test source

```ts
  35  | });
  36  | 
  37  | test('catalog search loads only the index and repeated selection loads one unchanged country chunk',async({page},testInfo)=>{
  38  |   test.setTimeout(120_000);
  39  |   const requests=[];page.on('request',request=>requests.push(request.url()));
  40  |   await gotoEditor(page, '/');
  41  |   await expect(page.locator('#app')).toHaveAttribute('data-readiness','enhanced',{timeout:90_000});
  42  |   expect(requests.filter(url=>url.includes('/territorial-entities/'))).toEqual([]);
  43  |   await page.locator('#createMenuBtn').click();await page.locator('#addFromLibraryBtn').click();
  44  |   await expect(page.locator('#territorialLibrarySearchInput')).toBeEnabled();
  45  |   await page.locator('#territorialLibrarySearchInput').fill('대한민국');
  46  |   const row=page.locator('[data-library-entity-id="state:KOR"]');
  47  |   await expect(row).toBeVisible();
  48  |   expect(requests.filter(url=>url.includes('/territorial-entities/') && url.includes('.json.gz'))).toEqual([]);
  49  |   await row.click();await expect(page.locator('#territorialLibraryAddBtn')).toBeEnabled();
  50  |   await row.click();
  51  |   const [first,second]=await page.evaluate(()=>Promise.all([window.PANDOLAB_TERRITORIAL_LIBRARY.get('state:KOR'),window.PANDOLAB_TERRITORIAL_LIBRARY.get('state:KOR')]));
  52  |   expect(first).toEqual(second);expect(first.geometryVersions[0].versionId).toBe('state:KOR:natural-earth-5.1.1');
  53  |   expect(requests.filter(url=>url.includes('/territorial-entities/') && url.includes('index.json'))).toHaveLength(1);
  54  |   expect(requests.filter(url=>url.includes('/territorial-entities/') && url.includes('.json.gz')).map(url=>new URL(url).pathname)).toEqual(['/assets/data/territorial-entities/generated/v2/state-KOR.json.gz']);
  55  |   await page.locator('#territorialLibrarySearchInput').fill('독일');
  56  |   await expect(page.locator('#territorialLibraryResults > h3')).toHaveCount(0);
  57  |   await expect(page.locator('[data-library-entity-id="state:DEU"]')).toBeVisible();
  58  |   await expect(page.locator('[data-library-entity-id="state:DEU"] strong')).toHaveText('독일');
  59  |   await expect(page.locator('[data-library-entity-id="state:deutsche-demokratische-republik"]')).toBeVisible();
  60  |   await expect(page.locator('[data-library-entity-id="state:deutsche-demokratische-republik"] strong')).toHaveText('독일 민주공화국');
  61  |   await page.locator('#territorialLibraryReferenceDateInput').fill('1970');
  62  |   await expect(page.locator('[data-library-entity-id="state:DEU"]')).toBeVisible();
  63  |   await expect(page.locator('[data-library-entity-id="state:deutsche-demokratische-republik"]')).toBeVisible();
  64  |   await page.locator('[data-library-entity-id="state:deutsche-demokratische-republik"]').click();
  65  |   await expect(page.locator('#territorialLibraryPreview')).toContainText('국가의 부재를 뜻하지 않습니다');
  66  |   await expect(page.locator('#territorialLibraryAddBtn')).toBeDisabled();
  67  |   await page.locator('#territorialLibraryReferenceDateInput').fill('1989-04-25');
  68  |   await expect(page.locator('[data-library-entity-id="state:DEU"]')).toBeVisible();
  69  |   await expect(page.locator('[data-library-entity-id="state:deutsche-demokratische-republik"]')).toBeVisible();
  70  |   await expect(page.locator('#territorialLibraryPreview [data-geometry-version-id]')).toHaveAttribute('data-geometry-version-id','state:deutsche-demokratische-republik:1989-04-25-r1');
  71  |   await expect(page.locator('#territorialLibraryAddBtn')).toBeEnabled();
  72  |   const previewAspect=await page.locator('#territorialLibraryPreview svg path').evaluate(path=>{const b=path.getBBox();return b.width/b.height;});
  73  |   const sourceAspect=await page.evaluate(async()=>{const e=await window.PANDOLAB_TERRITORIAL_LIBRARY.get('state:deutsche-demokratische-republik');
  74  |     const points=e.geometryVersions[0].geometry.coordinates.flat(2),x=points.map(p=>p[0]),y=points.map(p=>p[1]);return (Math.max(...x)-Math.min(...x))/(Math.max(...y)-Math.min(...y));});
  75  |   expect(Math.abs(previewAspect-sourceAspect)).toBeLessThan(0.03);
  76  |   expect(await page.locator('#territorialLibraryPreview svg path').evaluate(path=>path.getBBox().height)).toBeGreaterThan(160);
  77  |   await page.screenshot({path:testInfo.outputPath('lineage-preview.png')});
  78  |   await page.locator('#territorialLibraryCloseBtn').click();
  79  |   await page.evaluate(()=>window.PANDOLAB_TERRITORIAL.select('DEU'));
  80  |   await page.locator('#flagMenuBtn').click();await page.locator('#flagLibraryBtn').click();
  81  |   await page.locator('#territorialLibraryReferenceDateInput').fill('');
  82  |   await page.locator('#territorialLibrarySearchInput').fill('일본');
  83  |   const flagSource=await page.evaluate(async()=> (await window.PANDOLAB_TERRITORIAL_LIBRARY.list()).find(e=>e.entityId==='state:JPN').metadata.defaultFlagDataUrl);
  84  |   const chunksBefore=requests.filter(url=>url.includes('/territorial-entities/') && url.includes('.json.gz')).length;
  85  |   await page.locator('[data-library-entity-id="state:JPN"]').click();
  86  |   await expect(page.locator('#territorialLibraryAddBtn')).toHaveText('적용');
  87  |   await page.locator('#territorialLibraryAddBtn').click();
  88  |   await expect.poll(()=>page.evaluate(()=>window.PANDOLAB_TERRITORIAL.get('DEU').properties.metadata.flagDataUrl)).toBe(flagSource);
  89  |   expect(requests.filter(url=>url.includes('/territorial-entities/') && url.includes('.json.gz'))).toHaveLength(chunksBefore);
  90  | 
  91  | });
  92  | 
  93  | test('East Germany static import preserves identity, archive, history and original source', async ({ page }, testInfo) => {
  94  |   test.setTimeout(process.env.PANDOLAB_DDR_EVIDENCE_DIR?420_000:240_000);
  95  |   const errors = await openLibrary(page);
  96  |   await page.locator('#territorialLibraryReferenceDateInput').fill('1989-04-25');
  97  |   await page.locator('#territorialLibrarySearchInput').fill('동독');
  98  |   await page.locator('[data-library-entity-id="state:deutsche-demokratische-republik"]').click();
  99  |   await expect(page.locator('#territorialLibraryPreview')).toBeVisible();
  100 |   await expect(page.locator('#territorialLibraryPreview details')).toHaveCount(0);
  101 |   await expect(page.locator('#territorialLibraryPreview svg path')).toHaveCount(1);
  102 |   await importFiniteSource(page, testInfo, 'state:deutsche-demokratische-republik', errors, { referenceDate: '1989-04-25' });
  103 |   const imported=await page.evaluate(()=>window.PANDOLAB_TERRITORIAL.list().find(e=>e.properties.sourceEntityId==='state:deutsche-demokratische-republik'));
  104 |   const source=await page.evaluate(()=>window.PANDOLAB_TERRITORIAL_LIBRARY.get('state:deutsche-demokratische-republik'));
  105 |   expect(source.geometryVersions[0].sourceId).toContain('adopted-dos-lsib-11.4+bkg-vg25');
  106 |   expect(source.geometryVersions[0].boundarySupplement.sections.filter(s=>s.id.startsWith('vg25-')).map(s=>s.id)).toEqual([
  107 |     'vg25-schaalsee-lake', 'vg25-bavaria-central', 'vg25-saxony-bavaria',
  108 |     'vg25-eichsfeld-north', 'vg25-harz-ecker', 'vg25-geismar-spahl',
  109 |   ]);
  110 |   expect(imported.geometry).toEqual(source.geometryVersions[0].geometry);
  111 |   if(process.env.PANDOLAB_DDR_EVIDENCE_DIR){
  112 |     const {writeFile}=await import('node:fs/promises'),{gzipSync}=await import('node:zlib');
  113 |     const {productionGeoPackage}=await import('../helpers/production-geopackage.mjs');
  114 |     const out=process.env.PANDOLAB_DDR_EVIDENCE_DIR;
  115 |     const focus=async (target,projection)=>{
  116 |       await target.evaluate(projection=>{const host=window.__PANDOLAB_MAP_HOST__;host.setViewState({projection,view:{...host.getViewState(),flatCenter:[12.5,52],flatZoom:12,globeRotation:[-12.5,-52,0],globeZoom:14}});host.requestRepaint('ddr-source-review');},projection);
  117 |       await target.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
  118 |     };
  119 |     await focus(page,'flat');await page.screenshot({path:out+'/app-web-shell-import.png'});
  120 |     const receipt=await page.evaluate(()=>window.__libraryBuildFileSnapshot());
  121 |     const audits=receipt.project.sourceInfo.imports.filter(row=>row.batchPrecisionAudit).map(row=>row.batchPrecisionAudit);
  122 |     expect(audits).toHaveLength(1);expect(audits[0].sourceEntityIds).toContain(source.entityId);
  123 |     expect(audits[0].discards).toHaveLength(4);
  124 |     const encoded=await productionGeoPackage('write',new ArrayBuffer(0),receipt.project,receipt.spatialState);
  125 |     const bytes=Buffer.from(encoded.buffer);
  126 |     await writeFile(out+'/app-export.gpkg.gz',gzipSync(bytes,{level:9}));
  127 |     const viewer=await page.context().newPage(),viewerErrors=[];
  128 |     viewer.on('pageerror',error=>viewerErrors.push(error.message));
  129 |     await viewer.goto('/?debug=1&demTerrain=raster');
  130 |     await expect(viewer.locator('#viewerStatus')).toHaveAttribute('data-ready','true',{timeout:90000});
  131 |     const packagePath=testInfo.outputPath('DDR-1989-source-review.gpkg');
  132 |     await writeFile(packagePath,bytes);
  133 |     await viewer.locator('#projectFileInput').setInputFiles(packagePath);
  134 |     await expect.poll(()=>viewer.evaluate(()=>window.__PANDOLAB_VIEWER__.documentSnapshot().territorialEntities.some(e=>e.properties.sourceEntityId==='state:deutsche-demokratische-republik')),{timeout:90000}).toBe(true);
> 135 |     await expect(viewer.locator('#viewerStatus')).toHaveAttribute('data-ready','true');
      |                                                   ^ Error: expect(locator).toHaveAttribute(expected) failed
  136 |     const opened=await viewer.evaluate(id=>{const document=window.__PANDOLAB_VIEWER__.documentSnapshot();
  137 |       const binding=document.timelineRecords.geometryBindings.find(row=>row.entityId===id);
  138 |       return {audits:document.sourceInfo.imports.filter(row=>row.batchPrecisionAudit).map(row=>row.batchPrecisionAudit),
  139 |         geometry:document.geometries.find(g=>g.id===binding.geometryRef.id&&g.version===binding.geometryRef.version).geojson};},imported.id);
  140 |     expect(opened.audits).toEqual(audits);
  141 |     expect(opened.geometry).toEqual(source.geometryVersions[0].geometry);
  142 |     await focus(viewer,'globe');await viewer.screenshot({path:out+'/web-viewer-file.png'});
  143 |     expect(viewerErrors).toEqual([]);
  144 |     await writeFile(out+'/web-app-proof.json',JSON.stringify({sourceId:source.entityId,geometryVersion:source.geometryVersions[0].versionId,objectId:imported.id,webFileBytes:bytes.length,appImport:true,undoRedo:true,webFileGeometryEqual:true,precisionAudits:audits,webErrors:viewerErrors,appErrors:errors}));
  145 |     await viewer.close();
  146 |   }
  147 | });
  148 | 
```