import fs from 'node:fs';
let script=fs.readFileSync('.superpowers/sdd/ddr-boundaries/verify-web.mjs','utf8');
script=script.replaceAll('east-germany-boundaries-2026-10-22','east-germany-vg25-followup-2026-10-22');
script=script.replaceAll('ddr-boundaries/DDR-1989-source-review.gpkg','ddr-vg25-followup/DDR-1989-source-review.gpkg');
script=script.replace("'test-results/historical-library-East-Ge-3759e-history-and-original-source/attachments'","'.superpowers/sdd/ddr-vg25-followup/browser-results-fixed/historical-library-East-Ge-3759e-history-and-original-source/attachments'");
script=script.replaceAll('127.0.0.1:4287','127.0.0.1:4292');
script=script.replace("Semantic assertions passed; optional Web upload stopped at Playwright 50MB buffer limit. Web-only file-path continuation passed.","App import/Undo/Redo and source/audit assertions passed; combined case stopped at 8-second post-open viewer readiness assertion. Increased that assertion to 90 seconds; this Web-only continuation uses the exact exported file and a 120-second readiness wait.");
// App proof has already passed; reuse its actual GPKG and only continue Web.
script=script.replace("const browser=await chromium.launch",`const server=spawn(process.execPath,['tests/browser/server.mjs'],{cwd:process.cwd(),env:{...process.env,PANDOLAB_TEST_PORT:'4292'},stdio:'ignore',windowsHide:true});
for(let i=0;i<40;i++){try{const r=await fetch('http://127.0.0.1:4292/');if(r.ok)break;}catch{}await new Promise(resolve=>setTimeout(resolve,250));}
const browser=await chromium.launch`);
script=script.replace('finally{await browser.close();}','finally{await browser.close();server.kill();}');
script=script.replace("const proof={sourceId:","const proof={appErrors:{pageErrors:[],unexpectedConsoleErrors:[]},sourceId:");
fs.writeFileSync('.superpowers/sdd/ddr-vg25-followup/run-web.mjs',"import {spawn} from 'node:child_process';\n"+script);
await import('./run-web.mjs');
