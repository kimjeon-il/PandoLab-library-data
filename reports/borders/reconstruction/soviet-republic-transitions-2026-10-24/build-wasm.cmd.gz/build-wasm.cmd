@echo off
call "D:\dev\worktrees\objects\build-native\emsdk\emsdk_env.bat"
if errorlevel 1 exit /b %errorlevel%
"D:\dev\worktrees\objects\.superpowers\sdd\2026-10-20-core-ci-webgl-timeout\tools\cmake\data\bin\cmake.exe" -S shared -B build-native/wasm -G "MinGW Makefiles" -DCMAKE_MAKE_PROGRAM=C:/Users/taeeu/Qt/Tools/mingw1310_64/bin/mingw32-make.exe -DCMAKE_TOOLCHAIN_FILE=D:/dev/worktrees/objects/build-native/emsdk/upstream/emscripten/cmake/Modules/Platform/Emscripten.cmake -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=OFF
if errorlevel 1 exit /b %errorlevel%
"D:\dev\worktrees\objects\.superpowers\sdd\2026-10-20-core-ci-webgl-timeout\tools\cmake\data\bin\cmake.exe" --build build-native/wasm --target pandoeditor_wasm --parallel 1
exit /b %errorlevel%
