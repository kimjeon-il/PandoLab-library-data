# SDD ledger — plan: user-approved Soviet transitions and datePrecision removal

Scope: fifteen approved transitions, existing-coordinate temporal links, remove active datePrecision and clock-dependent current-only selection. Existing independent-state dating is deferred. Preserve approved1922/Caspian source coordinates and periods. No main integration, branch propagation, deployment or native package.

1. Inventory/read policies and official dates: complete. App/data work/gis match origin. Foreign WIP is evolving concurrently; stage task hunks only.
2. Regression RED: two focused tests fail for old catalog v1 and Russian republic ending1991-12-25.
3. Implement source periods and one interval-driven catalog; delete obsolete editor/provenance field; build affected WASM only if C++ contract changes.
4. Regenerate only dependent chunks/catalog/meshes and metadata; scoped exact-day/month-end tests and web/app evidence.
5. Archive external reports, commit/push task-owned work/gis, remote SHA, cleanup.

Ruling: latest user explicitly deferred unknown modern-object dates; retain null endpoints without inventing observation-date starts. Period-only selection consequently treats such endpoints as unbounded under the existing temporal contract; record this incomplete data coverage rather than retain a hidden current-only flag.
Ruling: source geometries stay byte-for-byte structurally identical; new temporal versions may reuse an existing geometry. Parent runtime clipping remains the existing compiler policy.

2026-10-25 status: code commit545faedafaca06496ee01fe56bb615042f22af96 (not pushed). Source282 updates finished using canonical scoped write lease; all303 pre-existing coordinate geometries unchanged and two new RUS/KAZ versions reuse old coordinates. Five physical/hydro input hashes and1922 periods preserved. Chunk282 generation complete. Builtin world generation active session42898, childPID1172, wrapperPID5172; do not restart. One read-only debugger observation showed interval index104/133,1990-03-11–1990-03-20; expensive vendor intersection(IDN,SEN). Debugger resumed/disabled. Datawork/gis origin/HEAD0/0; apporigin/HEAD0/1 afterfetch. Two source transition/shape cases pass; generated interval case was accidentally included by broad test-name pattern and failed on still-old schema1 index while generator was unfinished (do not count as product failure/pass). Need generated-only+modern baseline cases after index2, prepared meshes, metadata, Web/App new two browser cases, scoped data store/pin, report finalisation, push work/gis only.

Final implementation, source preservation, generated transition, modern baseline and Web/App checks completed; app dbb57fe7bcdfb45522eb1a17f795fd1605e6af90 and runtime 127e51c3457df87786ecf3aa5ad98ded690928df pushed and confirmed. Report-only finalisation and owned-temp cleanup follow.
