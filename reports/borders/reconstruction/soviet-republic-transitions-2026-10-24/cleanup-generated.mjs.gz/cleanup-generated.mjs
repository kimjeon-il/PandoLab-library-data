import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {gunzipSync} from 'node:zlib';
import {libraryMaterializedRoot,libraryCheckout,withLibraryWrite} from '../../../tools/library-data.mjs';
const root=process.cwd(),report='D:/dev/PandoLab-library-data/reports/.edits/gis/borders/reconstruction/soviet-republic-transitions-2026-10-24';
const json=file=>JSON.parse(fs.readFileSync(file)),sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const view=libraryMaterializedRoot(root),checkout=libraryCheckout(root),archive=json(path.join(checkout,'archive/index.json'));
const oldIndex=json(path.join(report,'before-v1-index.json')),oldMesh=json(path.join(report,'before-v2-manifest.json'));
const newIndex=json('assets/data/builtin-world/generated/v1/index.json'),newMesh=json('assets/data/prepared-polygons/generated/v2/manifest.json');
if(newIndex.schemaVersion!==2||newMesh.algorithmSourceSha256!=='dd222091475843be993912db749c47b4ddf4fe89e23c3a97fe234058b2de5278')throw Error('Finish interval catalog and required meshes before cleanup');
const prefix='assets/data/builtin-world/generated/v1/';
const keep=new Set([...newIndex.entities.map(row=>prefix+row.file),prefix+newIndex.transport.url,...Object.values(newMesh.meshes).map(row=>row.url)]);
const previous=new Set([...oldIndex.entities.map(row=>prefix+row.file),prefix+oldIndex.transport.url,...Object.values(oldMesh.meshes).map(row=>row.url)]);
const candidates=[...previous].filter(name=>!keep.has(name)&&fs.existsSync(name)).map(logical=>{
 const entry=archive.files[logical];if(!entry)throw Error('Old output has no recoverable archive record: '+logical);
 const physical=path.join(fs.realpathSync(path.dirname(logical)),path.basename(logical)),relative=path.relative(view,physical);
 if(relative.startsWith('..')||path.isAbsolute(relative)||fs.lstatSync(physical).isSymbolicLink()||!fs.lstatSync(physical).isFile())throw Error('Unsafe generated output: '+logical);
 const bytes=fs.readFileSync(physical);if(sha(bytes)!==entry.sha256)throw Error('Old output changed since archiving: '+logical);
 return {logical,physical,entry,bytes:bytes.length,sha256:sha(bytes)};
});
const requests=candidates.map(row=>'HEAD:'+row.entry.stored);
if(requests.length){
 const data=execFileSync('git',['--no-lazy-fetch','cat-file','--batch'],{cwd:checkout,input:requests.join('\n')+'\n',maxBuffer:256*1024**2,env:{...process.env,GIT_NO_LAZY_FETCH:'1'}});let cursor=0;
 for(const row of candidates){const end=data.indexOf(10,cursor),header=data.subarray(cursor,end).toString().split(' ');if(header[1]!=='blob')throw Error('Archived bytes unavailable: '+row.logical);const length=Number(header[2]),stored=data.subarray(end+1,end+1+length);cursor=end+1+length+1;const decoded=row.entry.encoding==='gzip'?gunzipSync(stored):stored;if(sha(decoded)!==row.sha256)throw Error('Archive recovery differs: '+row.logical);}
}
const diskBefore=fs.statfsSync(view);let removed=[];
withLibraryWrite({root,prefixes:['assets/data/builtin-world/generated/v1/countries','assets/data/builtin-world/generated/v1/transport','assets/data/prepared-polygons/generated/v2']},()=>{
 if(libraryMaterializedRoot(root)!==view)throw Error('Runtime pin changed during cleanup');
 for(const row of candidates){if(sha(fs.readFileSync(row.physical))!==row.sha256||keep.has(row.logical)||fs.lstatSync(row.physical).isSymbolicLink())throw Error('Output changed during cleanup');fs.unlinkSync(row.physical);removed.push({path:row.logical,bytes:row.bytes,sha256:row.sha256,reason:'Superseded generated output, absent from current manifests; exact bytes recovered from local archive Git before unlink'});}
});
const diskAfter=fs.statfsSync(view),proof={removed,logicalBytes:removed.reduce((n,row)=>n+row.bytes,0),driveFreeBytesObservedChange:diskAfter.bavail*diskAfter.bsize-diskBefore.bavail*diskBefore.bsize,driveDeltaAttribution:'Concurrent filesystem work prevents attributing drive free-space change solely to this cleanup',retainedCurrentOutputs:'Country files referenced by schema2 catalog, its packed transport, and prepared meshes referenced by the current manifest'};
fs.writeFileSync(path.join(report,'generated-cleanup.json'),JSON.stringify(proof,null,2)+'\n');console.log(JSON.stringify({files:removed.length,logicalBytes:proof.logicalBytes,driveFreeBytesObservedChange:proof.driveFreeBytesObservedChange}));
