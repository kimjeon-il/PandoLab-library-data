# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: soviet-transition-periods.spec.mjs >> Web viewer changes Russia and its Soviet phase by their dates
- Location: tests\browser\soviet-transition-periods.spec.mjs:9:1

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator:  locator('#timelineMonthButtonText')
Expected: "1991년 11월"
Received: "1991년 12월"
Timeout:  8000ms

Call log:
  - Expect "toHaveText" with timeout 8000ms
  - waiting for locator('#timelineMonthButtonText')
    18 × locator resolved to <span id="timelineMonthButtonText">1991년 12월</span>
       - unexpected value "1991년 12월"

```

```yaml
- text: 1991년 12월
```

# Test source

```ts
  1  | import {test,expect} from '@playwright/test';
  2  | import {writeFileSync} from 'node:fs';
  3  | import {gotoEditor} from './helpers/editor-entry.mjs';
  4  | 
  5  | test.use({viewport:{width:1440,height:900},trace:'off'});
  6  | const ids=['RUS','state:soviet-union-russian-sfsr','state:soviet-union'];
  7  | function record(snapshot){return snapshot.territorialEntities.filter(row=>ids.includes(row.id)).map(row=>({id:row.id,lifetime:row.properties.metadata.historicalTimeline.lifetime,version:row.properties.sourceGeometryVersion}));}
  8  | 
  9  | test('Web viewer changes Russia and its Soviet phase by their dates',async({page},info)=>{
  10 |  test.setTimeout(180000);
  11 |  const errors=[];page.on('pageerror',error=>errors.push(error.message));
  12 |  await page.clock.setFixedTime(new Date(1991,11,31,12));
  13 |  await page.goto('/?debug=1&demTerrain=raster');
  14 |  await expect(page.locator('#viewerStatus')).toHaveAttribute('data-ready','true',{timeout:120000});
  15 |  const december=record(await page.evaluate(()=>window.__PANDOLAB_VIEWER__.documentSnapshot()));
  16 |  expect(december.some(row=>row.id==='RUS')).toBe(true);
  17 |  expect(december.some(row=>row.id==='state:soviet-union-russian-sfsr')).toBe(false);
  18 |  expect(december.find(row=>row.id==='RUS').lifetime.validFrom).toBe('1991-12-25');
  19 |  await page.locator('#timelineMonthButton').click();
  20 |  await page.locator('#timelineYearInput').fill('1991');await page.locator('#timelineMonthInput').selectOption('11');await page.locator('#timelineGoBtn').click();
> 21 |  await expect(page.locator('#timelineMonthButtonText')).toHaveText('1991년 11월');
     |                                                         ^ Error: expect(locator).toHaveText(expected) failed
  22 |  await expect(page.locator('#viewerStatus')).toHaveAttribute('data-ready','true',{timeout:120000});
  23 |  const november=record(await page.evaluate(()=>window.__PANDOLAB_VIEWER__.documentSnapshot()));
  24 |  expect(november.some(row=>row.id==='RUS')).toBe(false);
  25 |  expect(november.find(row=>row.id==='state:soviet-union-russian-sfsr').lifetime.validTo).toBe('1991-12-24');
  26 |  expect(november.some(row=>row.id==='state:soviet-union')).toBe(true);expect(errors).toEqual([]);
  27 |  writeFileSync(info.outputPath('period-proof.json'),JSON.stringify({december,november,errors},null,2));
  28 |  await page.screenshot({path:info.outputPath('soviet-november.png')});
  29 | });
  30 | 
  31 | test('App web shell loads the December1991 independent phase',async({page},info)=>{
  32 |  test.setTimeout(180000);
  33 |  const errors=[];page.on('pageerror',error=>errors.push(error.message));
  34 |  await page.clock.setFixedTime(new Date(1991,11,31,12));
  35 |  await gotoEditor(page,'/?debug=1&renderer=webgl2');
  36 |  await expect(page.locator('#app')).toHaveAttribute('data-readiness','enhanced',{timeout:120000});
  37 |  const proof=await page.evaluate(()=>['RUS','state:soviet-union-russian-sfsr'].map(id=>{const row=window.PANDOLAB_TERRITORIAL.get(id);return {id,exists:Boolean(row),lifetime:row?.properties.metadata.historicalTimeline.lifetime,parentId:row?.properties.parentId,hasGeometry:Boolean(row?.geometry?.coordinates.length)};}));
  38 |  expect(proof[0].exists).toBe(true);expect(proof[0].lifetime.validFrom).toBe('1991-12-25');
  39 |  expect(proof[0].parentId).toBe('');expect(proof[0].hasGeometry).toBe(true);expect(proof[1].exists).toBe(false);expect(errors).toEqual([]);
  40 |  writeFileSync(info.outputPath('period-proof.json'),JSON.stringify({proof,errors},null,2));
  41 |  await page.screenshot({path:info.outputPath('independent-december.png')});
  42 | });
  43 | 
```