import json,hashlib,pathlib,datetime
root=pathlib.Path.cwd()
report=pathlib.Path('D:/dev/PandoLab-library-data/reports/.edits/gis/geography/soviet-republic-transitions-2026-10-24')
before=json.loads((report/'before-inventory.json').read_text(encoding='utf-8'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def canon(value):
 if isinstance(value,(float,int)):return format(float(value),'.17g')
 if isinstance(value,list):return [canon(x) for x in value]
 if isinstance(value,dict):return {k:canon(v) for k,v in value.items()}
 return value
def digest(geometry):return sha(json.dumps(canon(geometry),ensure_ascii=False,separators=(',',':')).encode())
def retired(value):
 if isinstance(value,list):return any(map(retired,value))
 if isinstance(value,dict):return any(k in ('datePrecision','geometryDatePrecision') or retired(v) for k,v in value.items())
 return False
files={json.loads(p.read_text(encoding='utf-8'))['entityId']:p for p in (root/'assets/data/territorial-entities/source/countries').glob('*.json')}
assert set(files)=={s['entityId'] for s in before['sources']}
old_shapes={v['geometryNumericSha256'] for s in before['sources'] for v in s['versions']}
modified=[];existing=0;added=[]
transitions=json.loads((report/'transitions.json').read_text())
affected={row[k] for row in transitions['rows'] for k in ('independentId','republicId')}
for old in before['sources']:
 p=files[old['entityId']];data=p.read_bytes();source=json.loads(data)
 assert not retired(source),p
 assert source['parentEntityId']==old['parentEntityId'],p
 if source['entityId'] not in affected:assert source['lifetime']==old['lifetime'],p
 versions={v['versionId']:v for v in source['geometryVersions']}
 for version in old['versions']:
  assert version['versionId'] in versions
  assert digest(versions[version['versionId']]['geometry'])==version['geometryNumericSha256'],version['versionId']
  existing+=1
 for version in source['geometryVersions']:
  assert digest(version['geometry']) in old_shapes,version['versionId']
  if version['versionId'] not in {v['versionId'] for v in old['versions']}:added.append(version['versionId'])
 if sha(data)!=old['sha256']:modified.append(source['entityId'])
 for v in source['geometryVersions']:
  if v['versionId'].endswith(':1922-12-30-reviewed-v2'):assert (v['validFrom'],v['validTo'])==('1922-12-30','1925-05-12')
protected={}
for name,expected in before['protectedInputs'].items():
 actual=sha((root/name).read_bytes());assert actual==expected,name;protected[name]=actual
proof={'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sources':len(files),'modifiedSourceFiles':len(modified),'existingGeometriesUnchanged':existing,'newVersionsReusingExistingCoordinates':added,'retiredPrecisionFields':0,'protectedInputs':protected,'otherLifetimesAndAllParentsPreserved':True,'approved1922PeriodsPreserved':True,'numericCanonicalization':before['coordinateCheck']}
(report/'coordinate-preservation.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(proof,ensure_ascii=False))
