# B-only standalone candidate — not applied

사용자 승인 범위: B만 단순화·접합한 파일 제작. 저장소 반영·날짜 확정·다른 동시 작업 수정 없음.

## Baseline / concurrency
Pinned source: main **287eeeadee**, data **36210d5f**. These files are NOT the latest concurrent work/gis snapshot. Future application MUST reconcile against then-current data. Concurrent work/gis/Pando work was not read into or modified by this preparation.

## Files
- B-1955-simplified-maxzoom.geojson: original candidate simplified only; original endpoints preserved.
- B-1955-simplified-joined-preview.geojson: same18-vertex line, but ONLY two endpoints adjusted to exact103.53E and103.82E intersections on pinned existing shared border.
- B-paired-country-preview.geojson: existing pinned Mongolia and USSR geometries with ONLY B segment replaced by identical reversed joined line. NOT globally reconstructed1976 countries. All new features undated, no lifetime/version dates assigned.
- B-app-maxzoom-preview.png: requested app-scale context (flatZoom64,1280CSSpx mapwidth).
- B-app-join-detail.png: enlarged inspection view, explicitly NOT actual CSS scale.
- report.json: calculations, joins and GEOS topology checks.
- prepare.py: reproducible standalone preparation. Outputs only this research subdirectory.

## Simplification
Equirectangular app scale=1280×64/360=227.5555556CSSpx per degree on BOTH axes. Douglas–Peucker tolerance0.5CSSpx=0.002197265625degrees. Master60→18vertices. Maximum distance of any original master vertex to simplified polyline=**0.4175358523CSSpx**. This statistic describes simplification, not endpoint joining or source-map accuracy. Original60-point master remains untouched.

Endpoint adjustments, separately reported: west1.4276391111CSSpx; east0.6284126155CSSpx. These are intentional preview joins, not inferred historical border geometry. Westjoin [103.53,50.155631195312374]; eastjoin [103.82,50.1853015788765]. A untouched.

## Verified
Native installed GEOS library checked both original and patched full polygons valid. Mongolia–USSR union symmetric-difference area=0; overlap before=0; overlap after=0. Shared replacement coordinates identical in reverse order. Exact equality of all outside-B vertex slices, all untouched rings and all other USSR polygons asserted. Thus this local patch produces no union gap or overlap and no changes outside B. Geographic areas computed only for topology equality, not territorial-area estimates.

1955 printed border remains an unverified cartographic candidate with several-km source uncertainty. Historical transition date unresolved and absent. No commit/push/repository data overwrite performed.
